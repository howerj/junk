/*
 * Ad-hoc 16-bit Tcode/0 virtual machine
 * Nils M Holm, 2017,2022,2023,2024
 * Public domain / 0BSD license
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>

/*
 * Define EXTRA to enable t3x.trunc and t3x.break.
 * (Better define this in the Makefile)
 */
/* #define EXTRA */

#define byte	unsigned char
#define cell	unsigned long

#ifdef unix
 #include <unistd.h>
#endif

#ifdef DEMOMODE
 unsigned Output = 0;
 #undef SYSTEM
 #undef CONSOLE
 #define EXTRA
#endif

#ifdef SYSTEM
 int t3x_mkdir(char *s);
 int t3x_rmdir(char *s);
 int t3x_chdir(char *s);
 int t3x_getdir(cell k, char *b);
 int t3x_dup(cell fd);
 int t3x_dup2(cell fd2, cell fd);
 int t3x_opendir(void);
 int t3x_readdir(cell k, char *b);
 int t3x_closedir(void);
 int t3x_isdir(char *s);
 int t3x_spawn(char **args, char *prog);
 int t3x_gettime(unsigned char *tb);
 int t3x_getftime(unsigned char *tb, char *s);
 int t3x_getfsize(unsigned char *sb, char *s);
 int t3x_spawn(char **args, char *prog);
 int t3x_ready(cell ms, cell fd);
#endif /* SYSTEM */

#ifdef CONSOLE
 void t3x_setup(int p);
 void t3x_shutdown(void);
 void t3x_clrscr(void);
 void t3x_clreol(void);
 void t3x_move(int x, int y);
 void t3x_scroll(void);
 void t3x_rscroll(void);
 void t3x_refresh(void);
 int t3x_getkey(void);
 int t3x_pollkey(void);
 void t3x_wrch(int c);
 void t3x_writes(char *s);
 void t3x_calibrate(int m);
 void t3x_wait(int hs);
 void t3x_standout();
 void t3x_normal();
#endif /* CONSOLE */

#undef DEBUG

#ifdef EXTRA
 #include <signal.h>
#endif

#define MEMSIZE	0xfffe

byte	*M;
cell	Red;

char	**Args;
cell	Narg;

void writes(char *s) { write(1, s, strlen(s)); }
void wlog(char *s) { write(2, s, strlen(s)); }

void fail(char *s) {
	wlog("tcvm: ");
	wlog(s);
	wlog("\n");
	exit(EXIT_FAILURE);
}

void load(char *s) {
	int	fd, k;
	char	b[6];
	char	p[100];

	k = strlen(s);
	if (k > 96) fail("file name too long");
	strcpy(p, s);
	if (k < 4 || strcmp(&s[k-3], ".tc"))
		strcat(p, ".tc");
	fd = open(p, O_RDONLY);
	if (fd < 0) fail("could not open program");
#ifdef __TURBOC__
	setmode(fd, O_BINARY);
#endif
	k = read(fd, b, 6);
	if (k != 6 || memcmp(b, "T3X0", 4)) fail("not a tcvm program");
	M = malloc(MEMSIZE);
	if (NULL == M) fail("not enough memory");
	Red = read(fd, M, MEMSIZE);
	close(fd);
}

cell	A, F, I, P;

cell w(cell a) { return  M[a+0] | (M[a+1] << 8); }

void Sw(cell a, cell w) {
	M[a+0] =  w        & 255;
	M[a+1] = (w >> 8)  & 255;
}

void push(cell x) {
	P -= 2;
	Sw(P, x);
}

cell pop(void) {
	P += 2;
	return w(P-2);
}
#ifdef __TURBOC__                                                               
 int S(cell x) { return (int) x; }
#else                                                                           
 int S(cell x) { return x > 32767? (int) x - 65536: x; }
#endif

#define a()	w(I+1)
#define a2()	w(I+3)

cell memscan(cell p, cell c, cell k) {
	cell	i;

	for (i=0; i<k; i++)
		if (M[p+i] == c)
			return i;
	return 0xffff;
}

cell getarg(cell n, char *s, cell k) {
	cell	j, m;

	n++;
	k--;
	if (n >= Narg) return 0xffff;
	j = strlen(Args[n]);
	m = j>=k? k: j;
	memcpy(s, Args[n], m);
	s[m] = 0;
	return m;
}

cell t3xopen(char *s, cell mode) {
	int	r;

	if (1 == mode)
		r = creat(s, 0644);
	else if (3 == mode)
		r = open(s, O_WRONLY);
	else
		r = open(s, w(P+2));
#ifdef __TURBOC__
	if (r > 0) setmode(r, O_BINARY);
#endif
	if (3 == mode) lseek(r, 0L, SEEK_END);
	return r < 0? 0xffff: r;
}

cell t3xseek(cell fd, cell where, cell how) {
	long	w;
	int	h;

	switch (how) {
		case 0:	w = where; h = SEEK_SET; break;
		case 1: w = where; h = SEEK_CUR; break;
		case 2: w = where; w = -w; h = SEEK_END; break;
		case 3: w = where; w = -w; h = SEEK_CUR; break;
		default: return 0xffff;
	}
	return lseek(fd, w, h) < 0? 0xffff: 0;
}

cell t3xtrunc(cell fd) {
#ifndef EXTRA
	fail("t3x.trunc not implemented");
	return 0;
#else
 #ifdef unix
	return ftruncate(fd, lseek(fd, 0, SEEK_CUR)) < 0? 0xffff: 0;
 #endif
 #ifdef __TURBOC__
	return write(fd, "", 0);
 #endif
#endif
}

cell t3xwrite(int fd, void *b, int k) {
#ifdef DEMOMODE
	Output += k;
	if (Output > 10240) fail("output limit exceeded");
#endif
	return write(fd, b, k);
}

char	*Sem;

void handle_break(int dummy) {
	Sem[0] = Sem[1] = -1;
#ifdef EXTRA
 #ifdef unix
	signal(SIGINT, handle_break);
 #endif
#endif
}

cell t3xbreak(cell sem) {
#ifndef EXTRA
	fail("t3x.break not implemented");
#else
 #ifdef unix
	if (0 == sem) {
		signal(SIGINT, SIG_DFL);
	}
	else if (1 == sem) {
		/* ignore */
	}
	else {
		Sem = (char *) &M[sem];
		Sem[0] = Sem[1] = 0;
		signal(SIGINT, handle_break);
	}
 #endif
 #ifdef __TURBOC__
	fail("t3x.break not implemented");
 #endif
#endif
	return 0;
}

cell t3x_memcmp(byte *a, byte *b, cell k) {
	int	r;

	r = memcmp(a, b, k);
	if (r < 0) return 0xffff;
	if (r > 0) return 1;
	return 0;
}

#ifdef SYSTEM
int tcvm_spawn(unsigned char *args, char *prog) {
	char	*a[100];
	int	i, n;

	i = 0;
	n = args[2*i+1] << 8 | args[2*i];
	while (n) {
		if (i >= 100) return -1;
		a[i] = (char *) &M[n];
		i++;
		n = args[2*i+1] << 8 | args[2*i];
	}
	a[i] = 0;
	return t3x_spawn(a, prog);
}
#endif /* SYSTEM */

cell libcall(cell n) {
	cell	r;

#ifdef DEBUG
	printf("LIBCALL(%d): %x %x %x %x", n, w(P+6), w(P+4), w(P+2), w(P));
#endif
	switch (n) {
	case  0: r = 2; break;
	case  1: strcpy((char *) &M[w(P+2)], "\n"); r = w(P+2); break;
	case  2: r = t3x_memcmp(&M[w(P+6)], &M[w(P+4)], w(P+2)); break;
	case  3: memmove(&M[w(P+6)], &M[w(P+4)], w(P+2)); r = 0; break;
	case  4: memset(&M[w(P+6)], w(P+4), w(P+2)); r = 0; break;
	case  5: r = memscan(w(P+6), w(P+4), w(P+2)); break;
	case  6: r = getarg(w(P+6), (char *) &M[w(P+4)], w(P+2)); break;
	case 10: r = read(w(P+6), &M[w(P+4)], w(P+2)); break;
	case 11: r = t3xwrite(w(P+6), &M[w(P+4)], w(P+2)); break;
#ifndef DEMOMODE
	case  7: r = creat((char *) &M[w(P+2)], 0644); break;
	case  8: r = t3xopen((char *) &M[w(P+4)], w(P+2)); break;
	case  9: r = close(w(P+2)); break;
	case 12: r = t3xseek(w(P+6), w(P+4), w(P+2)); break;
	case 13: r = rename((char *) &M[w(P+4)], (char *)&M[w(P+2)]); break;
	case 14: r = remove((char *) &M[w(P+2)]); break;
	case 15: r = t3xtrunc(w(P+2)); break;
	case 16: r = t3xbreak(w(P+2)); break;
#endif
#ifdef SYSTEM
	case 96:  r = t3x_mkdir((char *) &M[w(P+2)]); break;
	case 97:  r = t3x_rmdir((char *) &M[w(P+2)]); break;
	case 98:  r = t3x_chdir((char *) &M[w(P+2)]); break;
	case 99:  r = t3x_getdir(w(P+2), (char *) &M[w(P+4)]); break;
	case 100: r = t3x_dup(w(P+2)); break;
	case 101: r = t3x_dup2(w(P+2), w(P+4)); break;
	case 102: r = t3x_opendir(); break;
	case 103: r = t3x_readdir(w(P+2), (char *) &M[w(P+4)]); break;
	case 104: r = t3x_closedir(); break;
	case 105: r = t3x_gettime(&M[w(P+2)]); break;
	case 106: r = t3x_getftime(&M[w(P+2)], (char *) &M[w(P+4)]); break;
	case 107: r = t3x_getfsize(&M[w(P+2)], (char *) &M[w(P+4)]); break;
	case 108: r = tcvm_spawn(&M[w(P+2)], (char*)&M[w(P+4)]); break;
	case 109: r = t3x_isdir((char *) &M[w(P+2)]); break;
	case 110: r = t3x_ready(w(P+2), w(P+4)); break;
#endif /* SYSTEM */
#ifdef CONSOLE
	case 112: t3x_setup(0); r = 0; break;
	case 113: t3x_shutdown(); r = 0; break;
	case 114: t3x_clrscr(); r = 0; break;
	case 115: t3x_clreol(); r = 0; break;
	case 116: t3x_move(w(P+2), w(P+4)); r = 0; break;
	case 117: t3x_scroll(); r = 0; break;
	case 118: t3x_rscroll(); r = 0; break;
	case 119: t3x_refresh(); r = 0; break;
	case 120: r = t3x_getkey(); break;
	case 121: r = t3x_pollkey(); break;
	case 122: t3x_wrch(w(P+2)); r = 0; break;
	case 123: t3x_writes((char *) &M[w(P+2)]); r = 0; break;
	case 124: t3x_calibrate(w(P+2)); r = 0; break;
	case 125: t3x_wait(w(P+2)); r = 0; break;
	case 126: t3x_standout(); r = 0; break;
	case 127: t3x_normal(); r = 0; break;
#endif /* CONSOLE */
	default: fail("bad library call"); r = 0; break;
	}
#ifdef DEBUG
	printf(" = %x\n", r);
#endif
	return r & 0xffff;
}

void handle_alarm(int dummy) {
	fail("run time limit exceeded");
}

void divchk(int x) {
	if (0 == x) fail("divide by zero");
}

void run(void) {
	cell	t;

#ifdef DEMOMODE
	signal(SIGALRM, handle_alarm);
	alarm(5);
#endif
	P = MEMSIZE;
	F = MEMSIZE;
	for (I = 0;; I++) {
#ifdef DEBUG
	printf("F=%04x P=%04x I=%04x %2x a=%04x A=%04x S0=%04x\n",
		F, P, I, M[I], a(), A, w(P));
#endif
	if (P < Red) fail("stack overflow");
	switch (M[I]) {
	case 0x01: push(A); break;
	case 0x02: A = 0; break;
	case 0x03: P += 2; break;
	case 0x04:
	case 0x05: A = a(); I += 2; break;
	case 0x06: A = F+a() & 0xffff; I += 2; break;
	case 0x07: A = w(a()); I += 2; break;
	case 0x08: A = w(F+a() & 0xffff); I += 2; break;
	case 0x09: Sw(a(), A); I += 2; break;
	case 0x0a: Sw(F+a() & 0xffff, A); I += 2; break;
	case 0x0b: Sw(pop(), A); break;
	case 0x0c: M[pop()] = (byte) A; break;
	case 0x0d: t = a(); Sw(t, w(t)+1 & 0xffff); I += 2; break;
	case 0x0e: t = a(); Sw(F+t & 0xffff, w(F+t & 0xffff)+1 & 0xffff);
		   I += 2; break;
	case 0x0f: A += S(a()); A &= 0xffff; I += 2; break;
	case 0x10:
	case 0x11: P += S(a()); P &= 0xffff; I += 2; break;
	case 0x12: push(P); break;
	case 0x13: Sw(a(), P); I += 2; break;
	case 0x14: A = (A<<1) + pop() & 0xffff; break;
	case 0x15: A = w(A); break;
	case 0x16: A = A + pop() & 0xffff; break;
	case 0x17: A = M[A]; break;
	case 0x18: push(I+2); I = a()-1; break;
	case 0x19: push(I); I = A-1; break;
	case 0x47:
	case 0x1a: I = a()-1; break;
	case 0x1b: I += M[I+1]+1; break;
	case 0x1c: if (0 == A) I = a()-1; else I += 2; break;
	case 0x1d: if (0 != A) I = a()-1; else I += 2; break;
	case 0x1e: if (S(pop()) >= S(A)) I = a()-1; else I += 2; break;
	case 0x1f: if (S(pop()) <= S(A)) I = a()-1; else I += 2; break;
	case 0x20: push(F); F = P; break;
	case 0x21: F = pop(); break;
	case 0x22: I = pop(); break;
	case 0x23: exit(a()); break;
	case 0x24: A = ~A+1 & 0xffff; break;
	case 0x25: A = ~A & 0xffff; break;
	case 0x26: A = 0==A? 0xffff: 0; break;
	case 0x27: A = pop() + A & 0xffff; break;
	case 0x28: A = (int) pop() - (int) A & 0xffff; break;
	case 0x29: A = S(pop()) * S(A) & 0xffff; break;
	case 0x2a: divchk(A); A = S(pop()) / S(A) & 0xffff; break;
	case 0x2b: divchk(A); A = pop() % A & 0xffff; break;
	case 0x2c: A = pop() & A; break;
	case 0x2d: A = pop() | A; break;
	case 0x2e: A = pop() ^ A; break;
	case 0x2f: A = (pop() << A) & 0xffff; break;
	case 0x30: A = pop() >> A; break;
	case 0x31: A = pop() == A? 0xffff: 0; break;
	case 0x32: A = pop() != A? 0xffff: 0; break;
	case 0x33: A = S(pop()) < S(A)? 0xffff: 0; break;
	case 0x34: A = S(pop()) > S(A)? 0xffff: 0; break;
	case 0x35: A = S(pop()) <= S(A)? 0xffff: 0; break;
	case 0x36: A = S(pop()) >= S(A)? 0xffff: 0; break;
	case 0x37: A = pop() * A & 0xffff; break;
	case 0x38: divchk(A); A = pop() / A & 0xffff; break;
	case 0x39: A = pop() < A? 0xffff: 0; break;
	case 0x3a: A = pop() > A? 0xffff: 0; break;
	case 0x3b: A = pop() <= A? 0xffff: 0; break;
	case 0x3c: A = pop() >= A? 0xffff: 0; break;
	case 0x80: A = libcall(M[I+1]); I = pop(); break;
	default:   fail("invalid opcode"); break;
	}}
}

int main(int argc, char **argv) {
	if (argc < 2) fail("usage: tcvm program [args]");
	Args = argv;
	Narg = argc;
	load(argv[1]);
	run();
	return EXIT_SUCCESS;
}
