!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!
!!	NMH BASIC II -- A Minimum BASIC Interpreter
!!
!!	T3X Version
!!
!!	Nils M Holm, 1991-1994, 2023, 2024
!!
!!	Fixed: string allocation and assignment
!!
!!	Changes: - # (NOT) now has lowest precedence
!!		 - improved LIST format
!!		 - simplified string allocation
!!
!!	COMPILE: TX0 -T TCVM BASIC
!!	     OR	 TX0 -T DOS BASIC
!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

use t3x: t;

const	S_LEN = 6,
	S_LP = 0,
	S_IP = 1,
	S_VP = 2,
	S_LIM = 3,
	S_STP = 4,
	S_ID = 5;

const	BUFZ = 128,
	BUFL = 64,
	NTOK = 39,
	TOKL = 6,
	BASE = 10,
	NVAR = 260,
	NSTR = 36,
	WSPC = 8192,
	STKL = 30*S_LEN;

struct	ERRCODES =
	EOK, ELLO, EOVF, ESYN, EILN, EDIV, ESBO, ESUB,
	EMEM, ENIM, ESTK, ENST, ETYP, EEOD, EARG, ESTP,
	EBRK, EXXX;

const	IOC_RWND = 100,
	IOC_APPD = 101,
	IOC_TRNC = 102;

struct	OPS =	_NULL, _NOT, _QUOTE, _LPAR, _RPAR, _MUL, _PLUS,
		_COMMA, _MINUS, _SLASH, _MOD,_COLON, _SEMI, _LESS,
		_EQU, _GRTR, _LSEQ, _NEQ, _GTEQ, _TO, _IF, _DIM,
		_END, _FOR, _LET, _NEW, _REM, _RUN, _ASC, _DATA,
		_GOTO, _LEN, _CALL, _FRE, _LIST, _LOAD, _NEXT,
		_POKE, _READ, _SAVE, _STEP, _STOP, _TRON, _VAL,
		_CHRS, _CMPS, _CLEAR, _GOSUB, _INPUT, _MIDS, _PEEK,
		_PRINT, _STRS, _TROFF, _IOCTL, _RSTOR, _RETRN,
		_SYSTM;

const	_INT = 254,
	_VAR = 253,
	_STR = 252,
	_TXT = 251;

var	line::BUFL+2, scratch::BUFL+2, scp, spad::BUFL+2, spad2::BUFL+2;
var	tokens, msgs;
var	space::WSPC, memtop, ptop;
var	progp, ivars, svars, sbufs;
var	intp, linep, tracing;
var	idev, odev, iod;
var	istack[STKL], isp;
var	advance;
var	datal, datap;
var	errflag;
var	brkflag;

length(s) return t.memscan(s, 0, 32767);

puts(s) t.write(odev, s, length(s));

nl() puts("\r\n");

putc(c) do var s::1;
	s::0 := c;
	t.write(odev, s, 1);
end

intstr(x, pad) do var i, k;
        if (x = 0) return "0";
        i := 0;
	i := 9;
        pad::9 := 0;
        k := x<0-> -x: x;
        while (k > 0) do
                i := i-1;
                pad::i := '0' + k mod 10;
                k := k/10;
        end
        if (x < 0) do
                i := i-1;
                pad::i := '-';
        end
        return @pad::i;
end

putd(x) do var pad::10;
	puts(intstr(x, pad));
end

ascint(s) do
	var	g, i, j;
	var	v;
	var	lim;

	i := 0;
	v := 0;
	g := 1;
	if (s::i = '-') do
		g := %1;
		i := i+1;
	end
	while ('0' <= s::i /\ s::i <= '9') do
		v := v*10 + s::i-'0';
		i := i+1;
	end
	return v*g;
end

decl error(1);

list(p) do var v, i, b, sp, dat;
	sp := 0;
	while (p::0) do
		ie (p::0 = _INT) do
			putd(p::2 << 8 | p::1);
			p := p + 2;
			if (p::1 >= _TXT) putc('\s');
			sp := 0;
		end
		else ie (p::0 = _VAR) do
			p := p + 2;
			v := (p::0 << 8 | p::%1) - ivars;
			putc(v/(10*t.bpw())+'A');
			v := v mod (10*t.bpw())/t.bpw();
			if (v) putc(v+'0');
			sp := 0;
		end
		else ie (p::0 = _STR) do
			p := p + 2;
			v := ((p::0<< 8 | p::%1) - svars) / t.bpw();
			putc(v>=26-> v-26+'0': v+'A');
			putc('$');
			sp := 0;
		end
		else ie (p::0 = _TXT) do
			putc(''');
			p := p+1;
			while (p::0) do
				putc(p::0);
				if (p::0 = ''') putc(''');
				p := p+1;
			end
			putc(''');
			if (p::1 >= _TXT) putc('\s');
			sp := 0;
		end
		else do
			if (p::0 > _SYSTM) return error(EXXX);
			i := 2*p::0-2;
			b := tokens[i];
			if (b & 128 /\ \sp) putc('\s');
			puts(tokens[i+1]);
			sp := 0;
			if (b & 64 /\ p::1) do
				putc('\s');
				sp := %1;
			end
		end
		p := p + 1;
	end
	nl();
end

error(e) do
	if (errflag) return;
	errflag := %1;
	if (e) do
		if (linep) nl();
		puts("**");
	end
	puts(msgs+(e<<2));
	if (e /\ e \= EXXX) do
		puts(" : ");
		ie (linep)
			list(linep+1);
		else
			puts(line);
	end
	nl();
	iod := %1;
	idev := T3X.SYSIN;
	return %1;
end

readline(s) do var k, i, d;
	s::0 := 255;
	k := t.read(idev, s, BUFL+2);
	if (k < 1) return -1;
	i := t.memscan(s, '\n', k);
	if (i < 0) return error(ELLO);
	d := k-i-1;
	if (d) t.seek(idev, d, T3X.SEEK_BCK);
	s::i := 0;
	if (s::(i-1) = '\r') do
		i := i-1;
		s::i := 0;
	end
	return i;
end

toupr(c) return 'a' <= c /\ c <= 'z' -> c-32: c;

upcase(s) while (s::0) do
		s::0 := toupr(s::0);
		s := s + 1;
	end

isalpha(c) return 'A' <= c /\ c <= 'Z';

isdig(c) return '0' <= c /\ c <= '9';

gen(x) do
	scratch::scp := x;
	scp := scp + 1;
end

genp(p, v) do
	gen(p);
	gen(v&0xFF);
	gen(v>>8);
end

kwfind(k, err) do var tc, i;
	tc := 1;
	i := 0;
	while (tokens[i]) do
		if (	k::0 = tokens[i] & 0x3f /\
			\t.memcomp(tokens[i+1], @k::1, tokens[i] & 0x3f))
		do
			gen(tc);
			return;
		end
		i := i+2;
		tc := tc + 1;
	end
	error(err);
end

kw(in) do var kwb::TOKL+1, p;
	p := 1;
	while(isalpha(in::0) \/ in::0 = '$' \/ in::0 = '(') do
		kwb::p := in::0;
		if (p > TOKL) return error(ESYN);
		p := p+1;
		in := in + 1;
		if (in::%1 = '(') leave;
	end
	kwb::0 := p;
	kwb::p := 0;
	kwfind(kwb, ESYN);
	return in;
end

oper(in) do var kwb::4;
	kwb::0 := 2;
	kwb::1 := in::0;
	kwb::2 := 0;
	kwb::3 := 0;
	if (in::0 = '<' \/ in::0 = '>') do
		if (in::1 = '=' \/ in::1 = '>' /\ kwb::1 = '<') do
			kwb::2 := in::1;
			in := in+1;
			kwb::0 := kwb::0 + 1;
		end
	end
	kwfind(kwb, ESYN);
	return in+1;
end

svar(in) do
	ie ('0' <= in::0 /\ in::0 <= '9')
		genp(_STR, (in::0-'0'+26)*t.bpw()+svars);
	else
		genp(_STR, (in::0-'A')*t.bpw()+svars);
	return in+2;
end

vvar(in) do var addr;
	if (in::1 = '$') return svar(in);
	addr := ivars + (in::0-'A')*10*t.bpw();
	if ('0' <= in::1 /\ in::1 <= '9') do
		in := in + 1;
		addr := addr + (in::0-'0')*t.bpw();
	end
	genp(_VAR, addr);
	return in+1;
end

num(in) do var v, o;
	if (in::1 = '$') return svar(in);
	v := 0;
	while (isdig(in::0)) do
		o := v;
		v := v * BASE;
		if (v < o) return error(EOVF);
		if (v / BASE \= o) return error(EOVF);
 		v := v + (in::0-'0');
		if (v < o) return error(EOVF);
		in := in + 1;
	end
	genp(_INT, v);
	return in;
end

text(in) do
	gen(_TXT);
	in := in + 1;
	while (%1) do
		if (\in::0) return error(ESYN);
		ie (in::0 = ''') do
			in := in+1;
			ie (in::0 = '\'')
				gen('\'');
			else
				leave;
		end
		else
			gen(in::0);
		in := in + 1;
	end
	gen(0);
	return in;
end

tokenize(in) do
	scp := 0;
	upcase(in);
	while (in::0) do
		while (in::0 = '\s' \/ in::0 = '\t') in := in + 1;
		if (\in::0) leave;
		ie (isalpha(in::0)) do
			ie (isalpha(in::1))
				in := kw(in);
			else
				in := vvar(in);
		end
		else ie (isdig(in::0)) in := num(in);
		else ie (in::0 = ''') in := text(in);
		else in := oper(in);
	end
	gen(0);
end

moveprog(new) do var i, len, diff;
	if (progp = new) return;
	diff := new - progp;
	len := ptop-progp+1;
	ie (new .< progp)
		for (i=0, len) new::i := progp::i;
	else
		for (i=len-1, %1, %1) new::i := progp::i;
	ptop := ptop + (new-progp);
	progp := new;
	if (linep) do
		intp := intp + diff;
		linep := linep + diff;
	end
end

findln(lno) do var cl, p;
	p := progp;
	while (p::0) do
		cl := p::3<<8 | p::2;
		if (cl >= lno) return p;
		p := p + p::0;
	end
	return ptop;
end

lineno(addr) return addr::3<<8 | addr::2;

decl	expr(0);

variable() do var v;
	v := intp::2<<8 | intp::1;;
	intp := intp + 3;
	if (intp::0 = _LPAR) do
		intp := intp + 1;
		v := v + expr() * t.bpw();
		if (intp::0 \= _RPAR) return error(ESYN);
		intp := intp + 1;
	end
	if (v .>= progp) return error(ESUB);
	return v;
end

match(tk) ie (intp::0 = tk)
		intp := intp + 1;
	  else
		error(ESYN);

decl strexpr(0);

f_asc() do var sp;
	sp := strexpr();
	match(_RPAR);
	return sp::0;
end

decl strfac(0);

f_cmps() do var s1, s2, l1, l2;
	s1 := strfac();
	l1 := length(s1);
	match(_COMMA);
	s2 := strfac();
	l2 := length(s2);
	match(_RPAR);
	return t.memcomp(s1, s2, l1>l2 -> l1: l2);
end

f_fre() do
	expr();
	match(_RPAR);
	return sbufs-ptop;
end

f_len() do var sp;
	sp := strexpr();
	match(_RPAR);
	return length(sp);
end

f_val() do var sp;
	sp := strexpr();
	match(_RPAR);
	return ascint(sp);
end

f_peek() do var	vp;
	vp := expr();
	match(_RPAR);
	return space::vp;
end

f_ioctl() do var dev, service, rc;
	dev := expr();
	match(_COMMA);
	service := expr();
	match(_RPAR);
	ie (service = IOC_RWND) rc := t.seek(dev, 0, T3X.SEEK_SET);
	else ie (service = IOC_APPD) rc := t.seek(dev, 0, T3X.SEEK_END);
	else ie (service = IOC_TRNC) rc := t.trunc(dev);
	else return error(EARG);
	return rc;
end

fac() do var v, ii;
	ii := intp::0;
	ie (ii = _INT) do
		v := intp::2<<8 | intp::1;
		intp := intp + 3;
		return v;
	end
	else ie (ii = _VAR) do
		v := variable();
		return v[0];
	end
	else ie (ii = _LPAR) do
		intp := intp + 1;
		v := expr();
		if (intp::0 \= _RPAR) return error(ESYN);
		intp := intp + 1;
		return v;
	end
	else ie (ii = _MINUS) do
		intp := intp + 1;
		return -fac();
	end
	else ie (ii = _ASC) do
		intp := intp + 1;
		return f_asc();
	end
	else ie (ii = _CMPS) do
		intp := intp + 1;
		return f_cmps();
	end
	else ie (ii = _VAL) do
		intp := intp + 1;
		return f_val();
	end
	else ie (ii = _LEN) do
		intp := intp + 1;
		return f_len();
	end
	else ie (ii = _PEEK) do
		intp := intp + 1;
		return f_peek();
	end
	else ie (ii = _IOCTL) do
		intp := intp + 1;
		return f_ioctl();
	end
	else ie (ii = _FRE) do
		intp := intp + 1;
		return f_fre();
	end
	else do
		return error(ESYN);
	end
end

term() do var v, v2, ii;
	v := fac();
	while (%1) do
		ii := intp::0;
		ie (ii = _MUL) do
			intp := intp + 1;
			v := v * fac();
		end
		else ie (ii = _SLASH) do
			intp := intp + 1;
			v2 := fac();
			if (v2 = 0) return error(EDIV);
			v := v / v2;
		end
		else ie (ii = _MOD) do
			intp := intp + 1;
			v2 := fac();
			if (v2 = 0) return error(EDIV);
			v := v mod v2;
		end
		else do
			return v;
		end
	end
end

sum() do var v, ii;
	v := term();
	while (%1) do
		ii := intp::0;
		ie (ii = _PLUS) do
			intp := intp + 1;
			v := v + term();
		end
		else ie (ii = _MINUS) do
			intp := intp + 1;
			v := v - term();
		end
		else do
			return v;
		end
	end
end

comp() do var v, ii;
	v := sum();
	while (%1) do
		ii := intp::0;
		ie (ii = _EQU) do
			intp := intp + 1;
			v := v = sum();
		end
		else ie (ii = _NEQ) do
			intp := intp + 1;
			v := v \= sum();
		end
		else ie (ii = _LESS) do
			intp := intp + 1;
			v := v < sum();
		end
		else ie (ii = _GRTR) do
			intp := intp + 1;
			v := v > sum();
		end
		else ie (ii = _LSEQ) do
			intp := intp + 1;
			v := v <= sum();
		end
		else ie (ii = _GTEQ) do
			intp := intp + 1;
			v := v >= sum();
		end
		else do
			return v;
		end
	end
end

expr() do
	ie (intp::0 = _NOT) do
		intp := intp + 1;
		return \comp();
	end
	else do
		return comp();
	end
end

strvar() do var sv;
	sv := intp::2<<8 | intp::1;
	intp := intp + 3;
	if (intp::0 = _LPAR) do
		intp := intp + 1;
		sv := sv + (expr() * t.bpw());
		if (intp::0 \= _RPAR) return error(ESYN);
		intp := intp + 1;
	end
	if (sv .>= ivars) return error(ESUB);
	return sv;
end

sf_chr() do var v;
	v := expr();
	match(_RPAR);
	spad::0 := v;
	spad::1 := 0;
	return spad;
end

sf_mid() do var s1, ln, str;
	ln := BUFL;
	str := strexpr();
	match(_COMMA);
	s1 := expr();
	if (intp::0 = _COMMA) do
		match(_COMMA);
		ln := expr();
	end
	match(_RPAR);
	s1 := s1-1;
	if (s1 < 0) s1 := 0;
	if (length(str) < s1) return "";
	if (length(@str::s1) < ln) return @str::s1;
	t.memcopy(spad, @str::s1, BUFL);
	spad::ln := 0;
	return spad;
end

sf_str() do var v;
	v := expr();
	match(_RPAR);
	return intstr(v, spad);
end

strfac() do var sv, ii;
	ii := intp::0;
	ie (ii = _TXT) do
		intp := intp+1;
		sv := intp;
		while (intp::0) intp := intp + 1;
		intp := intp + 1;
		return sv;
	end
	else ie (ii = _STR) do
		sv := strvar();
		sv := sv[0];
		return \sv-> "": sv;
	end
	else ie (ii = _CHRS) do
		intp := intp + 1;
		return sf_chr();
	end
	else ie (ii = _MIDS) do
		intp := intp + 1;
		return sf_mid();
	end
	else ie (ii = _STRS) do
		intp := intp + 1;
		return sf_str();
	end
	else do
		return error(ESYN);
	end
end

strexpr() do var sv, sv2, l1, l2;
	sv := strfac();
	while (%1) do
		ie (intp::0 = _PLUS) do
			t.memcopy(spad2, sv, BUFL+1);
			intp := intp + 1;
			sv2 := strfac();
			l1 := length(spad2);
			l2 := length(sv2);
			if (l1 + l2 > BUFL) return error(ESBO);
			t.memcopy(@spad2::l1, sv2, l2+1);
			sv := spad2;
		end
		else do
			return sv;
		end
	end
end

push(sp) do
	if (isp >= STKL-S_LEN) return error(ESTK);
	t.memcopy(@istack[isp], sp, S_LEN*t.bpw());
	isp := isp + S_LEN;
end

pick(sp) do
	if (isp < S_LEN) return error(ESTK);
	t.memcopy(sp, @istack[isp-S_LEN], S_LEN*t.bpw());
	return sp[S_ID];
end

pop() do
	isp := isp - S_LEN;
	if (isp < 0) error(ESTK);
end

trace() if (tracing /\ linep) do
		puts(" [");
		putd(lineno(linep));
		puts("]");
	end

c_if() do
	intp := intp + 1;
	while (%1) do
		if (\expr()) do
			if (\linep) error(EOK);
			linep := linep + linep::0;
			intp := @linep::4;
			return;
		end
		if (intp::0 \= _COMMA) leave;
		intp := intp + 1;
	end
end

let_var() do var dest, v;
	dest := variable();
	match(_EQU);
	v := expr();
	if (dest = %1) return;
	dest[0] := v;
end

allocstr() do
	sbufs := sbufs - BUFL - 1;
	if (sbufs .< ptop) do
		sbufs := sbufs + BUFL+1;
		return error(EMEM);
	end
	return sbufs;
end

asg_str(dp, s) do var v;
	v := dp[0];
	if (v = 0) do
		v := allocstr();
		dp[0] := v;
	end
	t.memcopy(v, s, BUFL+1);
end

let_str() do var destp, val;
	destp := strvar();
	ie (intp::0 = _EQU)
		intp := intp + 1;
	else
		return error(ESYN);
	val := strexpr();
	asg_str(destp, val);
end

c_dim() do var v;
	intp := intp + 1;
	while (%1) do
		if (intp::0 \= _VAR) return error(ESYN);
		v := intp::2<<8 | intp::1;
		intp := intp + 3;
		match(_LPAR);
		v := v + expr()*t.bpw();
		match(_RPAR);
		if (v + (ptop-progp) .>= sbufs \/ v .< ivars) error(EMEM);
		if (v .>= progp) moveprog(v);
		if (intp::0 \= _COMMA) leave;
		intp := intp + 1;
	end
end

c_for() do var v, sp[S_LEN];
	intp := intp + 1;
	v := variable();
	if (v = %1) return;
	sp[S_VP] := v;
	match(_EQU);
	sp[S_VP][0] := expr();
	match(_TO);
	sp[S_LIM] := expr();
	ie (intp::0 = _STEP) do
		intp := intp + 1;
		sp[S_STP] := expr();
	end
	else
		sp[S_STP] := 1;
	sp[S_LP] := linep;
	sp[S_IP] := intp;
	sp[S_ID] := _FOR;
	push(sp);
end

c_next() do var st, vp, sp[S_LEN];
	intp := intp + 1;
	if (pick(sp) \= _FOR) return error(ENST);
	pop();
	vp := sp[S_VP];
	st := sp[S_STP];
	vp[0] := vp[0] + st;
	if (st >= 0 -> vp[0] > sp[S_LIM]: vp[0] < sp[S_LIM]) return;
	push(sp);
	linep := sp[S_LP];
	intp := sp[S_IP];
	trace();
end

c_let() do
	intp := intp + 1;
	ie (intp::0 = _VAR) let_var();
	else ie (intp::0 = _STR) let_str();
	else error(ESYN);
end

c_clear() do var diff;
	intp := intp + 1;
	t.memfill(ivars, 0, NVAR*t.bpw());
	t.memfill(svars, 0, NSTR*t.bpw());
	sbufs := memtop;
	sbufs::0 := 0;
	moveprog(@space[NVAR+NSTR]);
	isp := 0;
	datal := 0;
	datap := 0;
end

c_new() do
	progp := @space[NSTR+NVAR];
	ptop := progp;
	c_clear();
	progp::0 := 0;
	ptop := progp;
	tracing := 0;
end

c_load() do var x;
	intp := intp+1;
	if (iod \= %1) error(ENST);
	match(_NOT);
	x := expr();
	if (errflag) return;
	idev := x;
	iod := idev;
end

c_run() do
	c_clear();
	linep := progp;
end

c_goto() do var lno, addr;
	intp := intp + 1;
	lno := expr();
	addr := findln(lno);
	if (lineno(addr) \= lno) return error(EILN);
	linep := addr;
	advance := 0;
end

c_list() do var sl, el, p;
	sl := 0;
	el := 32767;
	intp := intp + 1;
	if (intp::0) do
		sl := expr();
		el := sl;
		if (intp::0 = _COMMA) do
			intp := intp + 1;
			el := expr();
		end
	end
	p := progp;
	while (p::0 /\ lineno(p) < sl) p := p + p::0;
	while (p::0 /\ lineno(p) <= el) do
		list(p+1);
		p := p + p::0;
	end
end

c_poke() do var a;
	intp := intp + 1;
	a := expr();
	match(_COMMA);
	space::a := expr();
end

nextdata(type) do var v;
	if (\datap \/ \datap::0) do
		ie (datal)
			datal := datal + datal::0;
		else
			datal := progp;
		while (datal::0) do
			if (datal::4 = _DATA) leave;
			datal := datal + datal::0;
		end
		if (\datal::0) return error(EEOD);
		datap := @datal::5;
	end
	if (datap::0 \= type) return error(ETYP);
	ie (type = _INT) do
		v := datap::2<<8 | datap::1;
		datap := datap + 3;
	end
	else do
		v := datap+1;
		while (datap::0) datap := datap + 1;
		datap := datap + 1;
	end
	return v;
end

c_read() do var v, d;
	intp := intp + 1;
	while (\errflag) do
		ie (intp::0 = _VAR) do
			v := variable();
			if (v = %1) return;
			d := nextdata(_INT);
			v[0] := d;
		end
		else ie (intp::0 = _STR) do
			asg_str(strvar(), nextdata(_TXT));
		end
		else do
			return error(ESYN);
		end
		if (intp::0 \= _COMMA) leave;
		intp := intp + 1;
	end
end

c_save() do var p, ood;
	p := progp;
	ood := odev;
	intp := intp + 1;
	match(_NOT);
	odev := expr();
	while (p::0) do
		list(p+1);
		p := p + p::0;
	end
	odev := ood;
end

c_gosub() do var lno, addr, sp[S_LEN];
	intp := intp + 1;
	lno := expr();
	addr := findln(lno);
	if (lineno(addr) \= lno) return error(EILN);
	sp[S_LP] := linep;
	sp[S_IP] := intp;
	sp[S_ID] := _GOSUB;
	push(sp);
	linep := addr;
	advance := 0;
end

c_input() do var vp, v;
	intp := intp + 1;
	if (intp::0 = _NOT) do
		intp := intp + 1;
		v := expr();
		if (errflag) return;
		idev := v;
		return;
	end
	while (%1) do
		ie (intp::0 = _VAR) do
			vp := variable();
			readline(spad);
			v := ascint(spad);
			if (vp = %1) return;
			vp[0] := v;
		end
		else ie (intp::0 = _STR) do
			vp := strvar();
			readline(spad);
			upcase(spad);
			asg_str(vp, spad);
		end
		else do
			return error(ESYN);
		end
		if (intp::0 \= _COMMA) leave;
		intp := intp + 1;
	end
end


c_print() do var doNL, i, x;
	doNL := %1;
	intp := intp + 1;
	if (intp::0 = _NOT) do
		intp := intp + 1;
		x := expr();
		if (errflag) return;
		odev := x;
		return;
	end
	while (intp::0) do
		i := intp::0;
		ie (	i = _MINUS \/ i = _NOT  \/
			i = _LPAR  \/ i = _ASC  \/
			i = _LEN   \/ i = _VAL  \/
			i = _CMPS  \/ i = _PEEK \/
			i = _IOCTL \/ i = _INT  \/
			i = _VAR   \/ i = _FRE)
		do
			doNL := %1;
			putd(expr());
		end
		else ie (i = _CHRS \/ i =_MIDS \/
			i = _STRS \/ i = _TXT \/
			i = _STR)
		do
			doNL := %1;
			puts(strexpr());
		end
		else if (intp::0 \= _COLON) do
			return error(ESYN);
		end
		ie (intp::0 = _COMMA) do
			intp := intp + 1;
			putc('\t');
			doNL := 0;
		end
		else ie (intp::0 = _SEMI) do
			intp := intp + 1;
			doNL := 0;
		end
		else do
			if (intp::0 = _COLON) leave;
			if (intp::0) return error(ESYN);
		end
	end
	if (doNL) nl();
end

c_return() do var x, sp[S_LEN];
	if (pick(sp) \= _GOSUB) return error(ENST);
	linep := sp[S_LP];
	intp := sp[S_IP];
	pop();
	trace();
end

c_restor() do
	intp := intp+1;
	datap := 0;
	datal := 0;
end

c_system() halt 0;

c_stop() error(ESTP);

c_trace(on) do
	intp := intp + 1;
	tracing := on;
end

execute(pp) do var oldpp, ii;
	oldpp := intp;
	intp := pp;
	advance := %1;
	while (%1) do
		ii := intp::0;
		     ie (ii = _IF) do c_if(); loop; end
		else ie (ii = _DIM) c_dim();
		else ie (ii = _END) return error(isp-> ENST: EOK);
		else ie (ii = _FOR) c_for();
		else ie (ii = _LET) c_let();
		else ie (ii = _NEW) c_new();
		else ie (ii = _REM) return;
		else ie (ii = _RUN) do c_run(); return; end
		else ie (ii = _CALL) return error(ENIM);
		else ie (ii = _DATA) return;
		else ie (ii = _GOTO) do c_goto(); return; end
		else ie (ii = _LIST) c_list();
		else ie (ii = _LOAD) c_load();
		else ie (ii = _NEXT) c_next();
		else ie (ii = _POKE) c_poke();
		else ie (ii = _READ) c_read();
		else ie (ii = _SAVE) c_save();
		else ie (ii = _STOP) return c_stop();
		else ie (ii = _TRON) c_trace(%1);
		else ie (ii = _CLEAR) c_clear();
		else ie (ii = _GOSUB) do c_gosub(); return; end
		else ie (ii = _INPUT) c_input();
		else ie (ii = _PRINT) c_print();
		else ie (ii = _RSTOR) c_restor();
		else ie (ii = _RETRN) c_return();
		else ie (ii = _SYSTM) c_system();
		else ie (ii = _TROFF) c_trace(0);
		else return error(ESYN);
		ii := intp::0;
		     ie (ii = _COLON) intp := intp + 1;
		else ie (ii = 0) return;
		else return error(ESYN);
	end
end

run(pp) do
	isp := 0;
	t.break(@brkflag);
	execute(pp);
	if (linep) do
		while (\errflag /\ linep::0) do
			t.break(1);
			trace();
			execute(@linep::4);
			if (brkflag) error(EBRK);
			if (\linep) leave;
			if (advance) linep := linep + linep::0;
		end
	end
	if (isp) error(ENST);
end

delete(addr) do var i, k;
	k := addr::0;
	i := addr;
	while (i .< ptop) do
		i::0 := i::k;
		i := i+1;
	end
	ptop := ptop - k;
	ptop::0 := 0;
end

insert(addr, len) do var i;
	if (ptop + len >= sbufs) return error(EMEM);
	i := ptop;
	while (i .>= addr) do
		i::len := i::0;
		i := i-1;
	end
	ptop := ptop + len;
end

store() do var addr, lno, i;
	lno := scratch::2<<8 | scratch::1;
	if (lno < 0) return error(EILN);
	addr := findln(lno);
	if (lno = lineno(addr)) delete(addr);
	if (scp < 5) return;
	insert(addr, scp+1);
	addr::0 := scp+1;
	addr := addr + 1;
	for (i=0, scp) addr::i := scratch::i;
end

process(ln) do
	linep := 0;
	tokenize(ln);
	if (errflag) return;
	ie (scratch::0 = _INT)
		store();
	else if (scratch::0)
		run(scratch);
end

init() do var p;
	tokens := [
		66,"#", 2,"'", 2,"(", 2,")", 2,"*", 2,"+", 66,",",
		2,"-", 2,"/", 2,"\\",194,":", 66,";", 194,"<", 194,"=",
		194,">",
		195,"<=", 195,"<>", 195,">=", 195,"TO", 195,"IF",
		196,"DIM", 196,"END", 196,"FOR", 196,"LET", 196,"NEW",
		196,"REM", 196,"RUN",
		5,"ASC(", 197,"DATA", 197,"GOTO", 5,"LEN(", 197,"CALL",
		5,"FRE(", 197,"LIST", 197,"LOAD", 197,"NEXT", 197,"POKE",
		197,"READ", 197,"SAVE", 197,"STEP", 197,"STOP", 197,"TRON",
		5,"VAL(",
		6,"CHR$(", 6,"CMPS(", 198,"CLEAR", 198,"GOSUB",
		198,"INPUT", 6,"MID$(", 198,"PEEK(", 198,"PRINT",
		6,"STR$(", 198,"TROFF",
		7,"IOCTL(", 199,"RESTOR", 199,"RETURN", 199,"SYSTEM",
		0 ];
	msgs :=	packed [
		" OK",0,"LLO",0,"OVF",0,"SYN",0,"ILN",0,"DIV",0,
		"SBO",0,"SUB",0,"MEM",0,"NIM",0,"STK",0,"NST",0,
		"TYP",0,"EOD",0,"ARG",0,"STP",0,"BRK",0,"XXX",0 ];
	idev := T3X.SYSIN;
	odev := T3X.SYSOUT;
	c_new();
	t.break(@brkflag);
end

do var p, i, arg::128, dev;
	puts("NMH BASIC 2.1");
	nl();
	if (t.bpw() \= 2) do
		puts("16-BIT ONLY");
		nl();
		halt 1;
	end
	p := 1;
	while (t.getarg(p, arg, 128) > 0) do
		dev := t.open(arg, T3X.ORDWR);
		ie (dev < 0) do
			puts("! "); puts(arg);
		end
		else do
			puts("#");
			putd(dev);
			puts(" = ");
			puts(arg);
		end
		nl();
		p := p + 1;
	end
	svars := space;
	ivars := @space[NSTR];
	memtop := @space::(WSPC-1);
	init();
	iod := %1;
	while (%1) do
		while (readline(line) >= 0) do
			errflag := 0;
			process(line);
			if (idev = T3X.SYSIN) error(EOK);
		end
		if (iod \= %1) do
			idev := iod;
			iod := %1;
			error(EOK);
		end
	end
end
