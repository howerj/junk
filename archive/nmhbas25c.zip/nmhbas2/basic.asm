;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;;	NMH BASIC II -- A Minimum BASIC Interpreter
;;
;;		    Assembly Version
;;
;;	       Nils M Holm 1991-1994, 2023, 2024
;;
;;	COMPILE: tasm basic.asm
;;		 tlink basic.obj
;;		 exe2bin basic.exe basic.com
;;		 del basic.exe
;;
;;	CHANGES SINCE 1.2:
;;		- # (NOT) now has least precedence
;;		- more compact LIST output
;;		- tabs are no longer space characters
;;		- division is signed now (this is a bug fix!)
;;		- simplified string allocation
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


	.model tiny

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;	M A C R O S
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;;=============================================================================
;;	Stack Structure
S_LEN	equ	6	; in words
S_LP	equ	0	; line ptr
S_IP	equ	2	; instr ptr
S_VP	equ	4	; var ptr (FOR)
S_LIM	equ	6	; limit (FOR)
S_STP	equ	8	; step (FOR)
S_ID	equ	10	; frame type

;;=============================================================================
;;	Configuration
BUFL	equ	64		; string buf size
TOKL	equ	6		; max token len
BASE	equ	10		; numeric base
WSPC	equ	12228		; total workspc memory
STKL	equ	24*S_LEN	; FOR/GOSUB stack size
NVAR	equ	260		; # num variables
NSTR	equ	36		; # str variables
RSTK	equ	128		; cpu stack size

;;=============================================================================
;;	Error Codes
EOK	equ	0
ELLO	equ	1	; line too long
EOVF	equ	2	; overflow
ESYN	equ	3	; syntax error
EILN	equ	4	; invalid line
EDIV	equ	5	; div by zero
ESBO	equ	6	; str buf overflow
ESUB	equ	7	; bad subscript
EMEM	equ	8	; out of mem
ENIM	equ	9	; not implemented
ESTK	equ	10	; stk overflow
ENST	equ	11	; nesting error
ETYP	equ	12	; type error (READ)
EEOD	equ	13	; end of DATA
EARG	equ	14	; bad arg (IOCTL)
ESTP	equ	15	; STOP command
EBRK	equ	16	; keyboard break
EXXX	equ	17	; internal err

;;=============================================================================
;;	IOCTL Services
IOC_RWD	equ	100	; rewind
IOC_APD	equ	101	; append
IOC_TRC	equ	102	; truncate

;;=============================================================================
;;	Interpreter Tokens
_NOT	equ	1
_QUOTE	equ	2
_LPAR	equ	3
_RPAR	equ	4
_MUL	equ	5
_PLUS	equ	6
_COMMA	equ	7
_MINUS	equ	8
_SLASH	equ	9
_MOD	equ	10
_COLON	equ	11
_SEMI	equ	12
_LESS	equ	13
_EQU	equ	14
_GRTR	equ	15
_LSEQ	equ	16
_NEQ	equ	17
_GTEQ	equ	18
_IF	equ	19
_TO	equ	20
_DIM	equ	21
_END	equ	22
_FOR	equ	23
_LET	equ	24
_NEW	equ	25
_REM	equ	26
_RUN	equ	27
_ASC	equ	28
_DATA_	equ	29
_GOTO	equ	30
_LEN	equ	31
_CALL	equ	32
_FRE 	equ	33
_LIST	equ	34
_LOAD	equ	35
_NEXT	equ	36
_POKE	equ	37
_READ	equ	38
_SAVE	equ	39
_STEP	equ	40
_STOP	equ	41
_TRON	equ	42
_VAL	equ	43
_CHR$	equ	44
_CMPS	equ	45
_CLEAR	equ	46
_GOSUB	equ	47
_INPUT	equ	48
_MID$	equ	49
_PEEK	equ	50
_PRINT	equ	51
_STR$	equ	52
_TROFF	equ	53
_IOCTL	equ	54
_RSTOR	equ	55
_RETRN	equ	56
_SYSTM	equ	57

;;=============================================================================
;;	Interpreter Tokens, Internal
_INT	equ	254
_VAR	equ	253
_STR	equ	252
_TXT	equ	251

;;=============================================================================
;;	OS-dependant Stuff
DOS	equ	21h
SYSIN	equ	0
SYSOUT	equ	1
OS_READ	equ	3F00h
OS_WRIT	equ	4000h
OS_SEEK	equ	4201h
LF	equ	10
CR	equ	13
CMDLINE	equ	81h

;;=============================================================================
;;	Zero Page variables
SCP	equ	word ptr ds:[0FEh]	; scratch pad ptr
MEMTOP	equ	word ptr ds:[0FCh]	; top of memory
PROGP	equ	word ptr ds:[0FAh]	; prog ptr
PTOP	equ	word ptr ds:[0F8h]	; end of program+1
SBUFS	equ	word ptr ds:[0F6h]	; string bufs
INTP	equ	word ptr ds:[0F4h]	; instr ptr
LINEP	equ	word ptr ds:[0F2h]	; line ptr
TRACING	equ	word ptr ds:[0F0h]	; trace flag
IDEV	equ	word ptr ds:[0EEh]	; input dev
ODEV	equ	word ptr ds:[0ECh]	; output dev
IOD	equ	word ptr ds:[0EAh]	; i/o redir flag
ISP	equ	word ptr ds:[0E8h]	; stack ptr
ADVANCE	equ	word ptr ds:[0E6h]	; advance to next line flag
DATAL	equ	word ptr ds:[0E4h]	; DATA line
DATAP	equ	word ptr ds:[0E2h]	; DATA ptr

;;=============================================================================
;;	Token length mask
LENMASK	equ	03Fh

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;	C O D E
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

	.code
	org	100h

prog:	jmp	start


;;=============================================================================
;;	PUTS -- Write a string to ODEV
;;	IN:   DI=String
;;	OUT:  -
;;	REGS: ALL except SI
puts:	push	si
	mov	si,di
	call	strlen
	mov	cx,ax
	mov	bx,ODEV
	mov	dx,di
	mov	ax,OS_WRIT
	int	DOS
	pop	si
	ret


;;=============================================================================
;;	PUTC -- Write a character to ODEV
;;	IN:   AX=character
;;	OUT:  -
;;	REGS: ALL
_char	db	0,0
putc:	mov	_char,al
	mov	di,offset _char
	jmp	short puts


;;=============================================================================
;;	B2A -- Convert binary number to decimal ASCII
;;	IN:   AX=number
;;	OUT:  DI=ptr to string
;;	REGS: ALL
b2a:	mov	di,offset econv
	xor	si,si
	std
	mov	dx,ax
	xor	ax,ax
	stosb

	cmp	dx,0
	jge	_sig
	not	si
	neg	dx
_sig:	mov	ax,dx

nxb2a:	mov	cx,BASE
	xor	dx,dx
	div	cx
	xchg	ax,dx
	add	al,'0'
	stosb
	mov	ax,dx
	or	ax,ax
	jnz	nxb2a

endb2a:	or	si,si
	jz	_sig2
	mov	al,'-'
	stosb
_sig2:	inc	di
	ret


;;=============================================================================
;;	PUTD -- write a decimal number to ODEV
;;	IN:   AX=number
;;	OUT:  0
;;	REGS: ALL
putd:	call	b2a
	call	puts
	ret


;;=============================================================================
;;	PUTNL -- write a newline sequence to ODEV
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
putnl:	mov	di,offset crlf
	call	puts
	ret


;;=============================================================================
;;	ERROR -- interpreter error handler
;;	IN:   AX=error id
;;	OUT:  -
;;	REGS: ALL
error:	push	ax
	or	ax,ax
	jz	nohd

	cmp	LINEP,0
	jz	norun
	call	putnl

norun:	mov	di,offset errhd
	call	puts

nohd:	pop	di
	push	di
	shl	di,1
	shl	di,1
	add	di,offset msgs
	call	puts
	pop	ax
	or	ax,ax
	jz	notail
	cmp	ax,EXXX
	jz	notail

	mov	di,offset errmid
	call	puts

	cmp	LINEP,0
	jnz	lsterr

	mov	di,offset line
	call	puts
	jmp	short notail

lsterr:	mov	di,LINEP
	call	list

notail:	call	putnl
	mov	IDEV,SYSIN
	jmp	restart


;;=============================================================================
;;	READLINE -- read a line from IDEV
;;	IN:   DX=buffer
;;	OUT:  AX=bytes read, -1=EOF
;;	REGS: ALL
readline:
	mov	di,dx
	mov	al,255
	stosb
	push	dx
	mov	ax,OS_READ
	mov	bx,IDEV
	mov	cx,BUFL+2
	int	DOS
	or	ax,ax
	jnz	rdok

	pop	dx
	xor	ax,ax
	dec	ax
	ret

rdok:	pop	di
	push	ax
	mov	cx,ax
	inc	cx
	cld
	mov	al,LF
	repnz	scasb
	or	cx,cx
	jnz	rdok2
	mov	ax,ELLO
	call	error

rdok2:	mov	byte ptr [di-2],0
	dec	cx
	jz	noseek

	mov	dx,cx
	neg	dx
	xor	cx,cx
	dec	cx
	mov	bx,IDEV
	mov	ax,OS_SEEK
	int	DOS

noseek:	pop	ax
	ret


;;=============================================================================
;;	UPCASE -- convert string to upper case
;;	IN:   SI=String
;;	OUT:  -
;;	REGS: AX
upcase:	push	si
	cld

doupc:	lodsb
	or	al,al
	jz	endupc
	cmp	al,'a'
	jb	noup
	cmp	al,'z'
	ja	noup
	sub	al,32
	mov	[si-1],al
noup:	jmp	short doupc

endupc:	pop	si
	ret


;;=============================================================================
;;	ISALPHA -- check for alphabetic input (Upper case only)
;;	IN:   AX=character
;;	OUT:  CC=is alphabetic
;;	REGS: -
isalpha:
	cmp	al,'A'
	jb	noal
	cmp	al,'Z'
	ja	noal
	clc
	ret

noal:	stc
	ret


;;=============================================================================
;;	ISDIG -- check for numeric input, uses exit of ISALPHA
;;	IN:   AX=character
;;	OUT:  CC=is numeric
;;	REGS: -
isdig:	cmp	al,'0'
	jb	noal
	cmp	al,'9'
	ja	noal
	clc
	ret


;;=============================================================================
;;	GEN -- Generate token (append to the token stream)
;;	IN:   AX=token
;;	OUT:  -
;;	REGS: DI
gen:	mov	di,SCP
	inc	di
	mov	SCP,di
	add	di,offset scratch-1
	mov	[di],al
	ret


;;=============================================================================
;;	GENP -- Generate a prefixed value
;;	IN:   AX=prefix(token), BX=value
;;	OUT:  -
;;	REGS: AX DI
genp:	call	gen
	mov	ax,bx
	call	gen
	mov	al,ah
	call	gen
	ret


;;=============================================================================
;;	KWFIND -- Find keyword and generate a keyword token
;;	IN:   SI=Pointer to extracted KW
;;	OUT:  -
;;	REGS: ALL
kwfind:	mov	di,offset tokens
	mov	bx,1

kwnxt:	cmp	byte ptr [di],0
	jz	nokw

	push	si
	push	di
	cld
	mov	cl,[di]
	and	cx,LENMASK
	lodsb
	inc	di
	cmp	al,cl
	jnz	kwskip
	rep	cmpsb
	or	cx,cx
	jz	kwok

kwskip:	pop	di
	pop	si
	mov	al,[di]
	and	ax,LENMASK
	add	di,ax
	inc	bx
	jmp	short kwnxt

kwok:	pop	di
	pop	si
	mov	ax,bx
	call	gen
	ret

nokw:	mov	ax,ESYN
	call	error


;;=============================================================================
;;	KW -- tokenize a keyword
;;	IN:   SI=Pointer to KW
;;	OUT:  SI=pointer to next char
;;	REGS: ALL
kw:	cld
	mov	di,offset conv+1
	xor	bx,bx

nxttk:	lodsb
	cmp	al,'('
	jz	istk
	cmp	al,'$'
	jz	istk

	call	isalpha
	jc	eotk

istk:	stosb
	inc	bx
	cmp	bx,TOKL
	ja	ltok

	cmp	al,'('
	jnz	nxttk
	inc	si

eotk:	inc	bx
	mov	conv,bl

	push	si
	mov	si,offset conv
	call	kwfind
	pop	si

	dec	si
	ret

ltok:	mov	ax,ESYN
	call	error


;;=============================================================================
;;	SVAR -- tokenize a string variable, used by VAR
;;	IN:   AX=variable letter
;;	OUT:  SI=pointer to next char
;;	REGS: ALL
svar:	xor	ah,ah
	call	isdig
	jc	alstr

	sub	ax,'0'-26
	jmp	short gensv

alstr:	sub	ax,'A'

gensv:	shl	ax,1
	add	ax,offset svars
	mov	bx,ax
	mov	ax,_STR
	call	genp
	ret


;;=============================================================================
;;	VAR -- tokenize a variable, uses SVAR
;;	IN:   SI=pointer to variable name,AX=first char
;;	OUT:  SI=pointer to next char
;;	REGS: ALL
var:	xor	ah,ah
	mov	bx,ax
	cld
	lodsb
	cmp	al,'$'
	jnz	isnvar

	mov	ax,bx
	jmp	short svar

isnvar:	push	ax
	sub	bx,'A'
	mov	ax,20
	mul	bx
	mov	bx,ax
	pop	ax
	call	isdig
	jc	shrt

	sub	ax,'0'
	shl	ax,1
	add	bx,ax
	inc	si

shrt:	dec	si
	add	bx,offset ivars
	mov	ax,_VAR
	call	genp
	ret


;;=============================================================================
;;	NUM -- tokenize a number
;;	IN:   SI=pointer to number
;;	OUT:  SI=pointer to next character
;;	REGS: ALL
num:	xor	ah,ah
	mov	bx,ax
	cld
	lodsb
	cmp	al,'$'
	jnz	isnum

	mov	ax,bx
	jmp	short svar

isnum:	dec	si
	dec	si
	xor	dx,dx

nxtdig:	lodsb
	call	isdig
	jc	endnum

	push	ax
	mov	cx,dx
	mov	ax,BASE
	mul	dx
	cmp	ax,cx
	jl	ovf

	or	dx,dx
	jz	noovf

ovf:	mov	ax,EOVF
	call	error

noovf:	mov	dx,ax
	pop	ax
	sub	ax,'0'
	add	dx,ax
	cmp	dx,cx
	jl	ovf

	jmp	short nxtdig

endnum:	mov	bx,dx
	mov	ax,_INT
	call	genp
	dec	si
	ret

;;=============================================================================
;;	TEXT -- tokenize a text literal
;;	IN:   SI=pointer to text
;;	OUT:  SI=pointer to next char
;;	REGS: ALL
text:	mov	ax,_TXT
	call	gen

nxtch:	cld
	lodsb
	or	al,al
	jnz	txtok

	mov	ax,ESYN
	call	error

txtok:	cmp	al,"'"
	jnz	noqot

	lodsb
	cmp	al,"'"
	jnz	endtx

noqot:	call	gen
	jmp	short nxtch

endtx:	xor	ax,ax
	call	gen
	dec	si
	ret


;;=============================================================================
;;	OPER -- tokenize an operator
;;	IN:   SI=pointer to operator
;;	OUT:  SI=pointer to next character
;;	REGS: ALL
oper:	mov	conv,2
	mov	conv+1,al
	cmp	al,'<'
	jnz	nolo1

	cld
	lodsb
	cmp	al,'='
	jz	longop
	cmp	al,'>'
	jz	longop

	dec	si
	jmp	short shrtop

nolo1:	cmp	al,'>'
	jnz	shrtop

	lodsb
	cmp	al,'='
	jz	longop

	dec	si
	jmp	short shrtop

longop:	mov	conv+2,al
	inc	conv

shrtop:	push	si
	mov	si,offset conv
	call	kwfind
	pop	si
	ret


;;=============================================================================
;;	TOKENIZE -- convert line to token stream
;;	IN:   SI=line
;;	OUT:  -
;;	REGS: ALL
tokenize:
	cld
	mov	SCP,0
	call	upcase

dotok:	lodsb
	cmp	al,' '
	jz	dotok

	or	al,al
	jz	endtok

	call	isalpha
	jc	notal

	lodsb
	call	isalpha
	jc	notkw

	dec	si
	dec	si
	call	kw
	jmp	short dotok

notkw:	dec	si
	dec	si
	lodsb
	call	var
	jmp	short dotok

notal:	call	isdig
	jc	notnum
	call	num
	jmp	short dotok

notnum:	cmp	al,"'"
	jnz	isop
	call	text
	jmp	short dotok

isop:	call	oper
	jmp	short dotok

endtok:	xor	ax,ax
	call	gen
	ret


;;=============================================================================
;;	FINDLN -- find the address of a given line
;;	IN:   DX=line no
;;	OUT:  DI=address, CS=on PTOP
;;	REGS: ALL
findln:	mov	si,PROGP

nxtln:	mov	al,[si]
	or	al,al
	jz	endfl

	mov	ax,[si+2]
	cmp	ax,dx
	jae	gotln		; >= for inserting

	mov	al,[si]
	xor	ah,ah
	add	si,ax
	jmp	short nxtln

gotln:	mov	di,si
	clc
	ret

endfl:	mov	di,PTOP
	stc
	ret

;;=============================================================================
;;	DELETE - delete a line from a program
;;	IN:   DI=address of line
;;	OUT:  -
;;	REGS: ALL
delete:	mov	dl,[di]
	xor	dh,dh
	push	dx

	mov	si,di
	add	si,dx
	mov	cx,PTOP
	sub	cx,si
	inc	cx
	cld
	rep	movsb

	pop	ax
	sub	PTOP,ax
	ret


;;=============================================================================
;;	INSERT -- insert a line into a program
;;	IN:   DI=address, CX=length
;;	OUT:  -
;;	REGS: ALL
insert:	mov	si,di
	add	di,cx
	push	cx

	mov	cx,PTOP
	sub	cx,si
	add	si,cx
	add	di,cx
	inc	cx
	std
	rep	movsb

	pop	ax
	add	PTOP,ax
	ret

;;=============================================================================
;;	STORE -- modify a line in a program
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
store:	mov	si,offset scratch
	mov	dx,[si+1]
	call	findln
	jc	nodell

	mov	cx,[di+2]
	cmp	dx,cx
	jnz	nodell

	push	di
	call	delete
	pop	di

nodell:	cmp	SCP,5
	jl	nosto

	mov	cx,SCP
	inc	cx

	push	cx
	push	di
	call	insert
	pop	di
	pop	cx

	mov	[di],cl
	inc	di
	dec	cx
	cld
	mov	si,offset scratch
	rep	movsb

nosto:	ret


;;=============================================================================
;;	MOVEPROG -- move the program (when DIMensioning or CLEARing)
;;	IN:   DX=new position
;;	OUT:  -
;;	REGS: ALL
moveprog:
	cmp	PROGP,dx
	jz	endmp

	mov	ax,dx
	sub	ax,PROGP
	push	ax

	mov	cx,PTOP
	sub	cx,PROGP
	inc	cx

	mov	si,PROGP
	mov	di,dx
	cmp	dx,PROGP
	ja	mvup

	cld
	rep	movsb
	jmp	short mvdone

mvup:	add	si,cx
	dec	si
	add	di,cx
	dec	di
	std
	rep	movsb

mvdone:	mov	ax,dx
	sub	ax,PROGP
	add	PTOP,ax
	mov	PROGP,dx

	pop	ax
	cmp	LINEP,0
	jz	endmp

	add	INTP,ax
	add	LINEP,ax

endmp:	ret


;;=============================================================================
;;	MATCH -- match a token
;;	IN:   AL=token
;;	OUT:  -
;;	REGS: ALL
match:	mov	si,INTP
	mov	ah,[si]
	cmp	al,ah
	jnz	nomatch
	inc	INTP
	ret

nomatch:
	mov	ax,ESYN
	call	error


;;=============================================================================
;;	F_ASC -- Return ASCII code of a character [Basic:ASC()]
;;	IN:   -
;;	OUT:  DX=ASCII code
;;	REGS: ALL
f_asc:	call	strexpr
	mov	dl,[di]
	xor	dh,dh
	mov	ax,_RPAR
	call	match
	ret


;;=============================================================================
;;	F_CMPS -- Compare two strings [Basic:CMPS()]
;;	IN:   -
;;	OUT:  DX=difference of first unequal characters
;;	REGS: ALL
f_cmps:	call	strexpr
	push	di

	mov	ax,_COMMA
	call	match

	call	strexpr
	mov	ax,_RPAR
	call	match

	pop	si

cmpnx:	inc	di
	lodsb
	or	al,al
	jz	endcs
	cmp	al,[di-1]
	jz	cmpnx

endcs:	mov	al,[si-1]
	sub	al,[di-1]
	cbw
	mov	dx,ax
	ret


;;=============================================================================
;;	F_FRE -- Return number of free bytes in program memory
;;	IN:   -
;;	OUT:  DX=free memory
;;	REGS: ALL
f_fre:	call	expr
	mov	dx,SBUFS
	sub	dx,PTOP
	mov	ax,_RPAR
	call	match
	ret


;;=============================================================================
;;	F_LEN -- Return length of a string [Basic:LEN()]
;;	IN:   -
;;	OUT:  DX=length
;;	REGS: ALL
f_len:	call	strexpr
	mov	si,di
	call	strlen
	mov	dx,ax
	mov	ax,_RPAR
	call	match
	ret


;;=============================================================================
;;	F_VAL -- Return the value of a string [Basic:VAL()]
;;	IN:   -
;;	OUT:  DX=value
;;	REGS: ALL
f_val:	call	strexpr
	mov	ax,_RPAR
	call	match
	mov	si,di

a2b:	xor	di,di
	cld
	xor	bx,bx
	lodsb
	cmp	al,'-'
	jnz	nosgn

	dec	di

cnvnx:	lodsb
nosgn:	call	isdig
	jc	endsv

	push	ax
	mov	ax,BASE
	mul	bx
	mov	bx,ax
	pop	ax
	xor	ah,ah
	sub	ax,'0'
	add	bx,ax
	jmp	short cnvnx

endsv:	mov	dx,bx
	or	di,di
	jz	nosgn2

	neg	dx

nosgn2:	ret


;;=============================================================================
;;	F_PEEK -- Return the value of a given cell [Basic:PEEK()]
;;	IN:   -
;;	OUT:  DX=value
;;	REGS: ALL
f_peek:	call	expr
	mov	ax,_RPAR
	call	match
	mov	di,dx
	mov	dl,[di]
	xor	dh,dh
	ret


;;=============================================================================
;;	DO_SEEK -- reposition a device pointer
;;	IN:   AX=service code, BX=device desc.
;;	OUT:  DX=return code
;;	REGS: ALL
do_seek:
	xor	cx,cx
	mov	dx,cx
dodos:	int	DOS
	jc	dos_fail
	xor	dx,dx
	ret

dos_fail:
	mov	dx,ax
	ret


;;=============================================================================
;;	F_IOCTL -- Device Control [Basic:IOCTL()]
;;	IN:   -
;;	OUT:  DX=return code
;;	REGS: ALL
f_ioctl:
	call	expr
	mov	ax,_COMMA
	call	match
	push	dx

	call	expr
	mov	ax,_RPAR
	call	match
	pop	bx

	cmp	dx,IOC_RWD
	jnz	_rwnd

	mov	ax,4200h
	jmp	short do_seek

_rwnd:	cmp	dx,IOC_APD
	jnz	_apnd

	mov	ax,4202
	jmp	short do_seek

_apnd:	cmp	dx,IOC_TRC
	jnz	_trnc

	mov	ax,OS_WRIT
	xor	cx,cx
	jmp	short dodos

_trnc:	mov	ax,EARG
	call	error


;;=============================================================================
;;	VARIABLE -- deliver the address of a variable
;;	IN:   -
;;	OUT:  DI=address
;;	REGS: ALL
variable:
	mov	si,INTP
	mov	di,[si+1]
	add	INTP,3
	add	si,3
	cmp	byte ptr [si],_LPAR
	jnz	novsub

	inc	INTP
	push	di
	call	expr
	pop	di
	shl	dx,1
	add	di,dx
	mov	ax,_RPAR
	call	match

novsub:	cmp	di,PROGP
	jae	badvsub
	ret

badvsub:
	mov	ax,ESUB
	call	error


;;=============================================================================
;;	FAC -- evaluate a numeric factor
;;	IN:   -
;;	OUT:  DX=result
;;	REGS: ALL
fac:	mov	si,INTP
	mov	al,[si]
	cmp	al,_INT
	jnz	_fac1

	mov	dx,[si+1]
	add	INTP,3
	ret

_fac1:	cmp	al,_VAR
	jnz	_fac2

	call	variable
	mov	dx,[di]
	ret

_fac2:	cmp	al,_LPAR
	jnz	_fac3

	inc	INTP
	call	expr
	mov	al,_RPAR
	call	match
	ret

_fac3:	cmp	al,_MINUS
	jnz	_fac5

	inc	INTP
	call	fac
	neg	dx
	ret

_fac5:	cmp	al,_ASC
	jnz	_fac5a

	inc	INTP
	call	f_asc
	ret

_fac5a:	cmp	al,_FRE
	jnz	_fac6

	inc	INTP
	call	f_fre
	ret

_fac6:	cmp	al,_CMPS
	jnz	_fac7

	inc	INTP
	call	f_cmps
	ret

_fac7:	cmp	al,_LEN
	jnz	_fac8

	inc	INTP
	call	f_len
	ret

_fac8:	cmp	al,_VAL
	jnz	_fac9

	inc	INTP
	call	f_val
	ret

_fac9:	cmp	al,_PEEK
	jnz	_fac10

	inc	INTP
	call	f_peek
	ret

_fac10:	cmp	al,_IOCTL
	jnz	_fac11

	inc	INTP
	call	f_ioctl
	ret

_fac11: mov	ax,ESYN
	call	error


;;=============================================================================
;;	TERM -- evaluate a term
;;	IN:   -
;;	OUT:  DX=result
;;	REGS: ALL
term:	call	fac

nxte:	mov	si,INTP
	mov	al,[si]

	cmp	al,_MUL
	jnz	_te1

	inc	INTP
	push	dx
	call	fac
	pop	ax
	mul	dx
	mov	dx,ax
	jmp	short nxte

_te1:	cmp	al,_SLASH
	jnz	_te2

	inc	INTP
	push	dx
	call	fac
	or	dx,dx
	jz	divz
	pop	ax
	mov	cx,dx
	cwd
	idiv	cx
	mov	dx,ax
	jmp	short nxte

_te2:	cmp	al,_MOD
	jnz	tex

	inc	INTP
	push	dx
	call	fac
	or	dx,dx
	jz	divz
	pop	ax
	mov	cx,dx
	xor	dx,dx
	div	cx
	jmp	short nxte

tex:	ret

divz:	mov	ax,EDIV
	call	error


;;=============================================================================
;;	SUM -- evaluate a sum
;;	IN:   -
;;	OUT:  DX=result
;;	REGS: ALL
sum:	call	term

nxsu:	mov	si,INTP
	mov	al,[si]

	cmp	al,_PLUS
	jnz	_su1

	inc	INTP
	push	dx
	call	term
	pop	ax
	add	dx,ax
	jmp	short nxsu

_su1:	cmp	al,_MINUS
	jnz	sux

	inc	INTP
	push	dx
	call	term
	pop	ax
	xchg	dx,ax
	sub	dx,ax
	jmp	short nxsu

sux:	ret


;;=============================================================================
;;	COMP -- evaluate a comparison
;;	IN:   -
;;	OUT:  DX=result
;;	REGS: ALL
comp:	call	sum

nxex:	mov	si,INTP
	mov	al,[si]

	cmp	al,_EQU
	jnz	_ex1

	inc	INTP
	push	dx
	call	sum
	pop	ax
	cmp	ax,dx
	jz	true

false:	xor	dx,dx
	jmp	short nxex

true:	xor	dx,dx
	dec	dx
	jmp	short nxex

_ex1:	cmp	al,_NEQ
	jnz	_ex2

	inc	INTP
	push	dx
	call	sum
	pop	ax
	cmp	ax,dx
	jnz	true
	jmp	short false

_ex2:	cmp	al,_LESS
	jnz	_ex3

	inc	INTP
	push	dx
	call	sum
	pop	ax
	cmp	ax,dx
	jl	true
	jmp	short false

_ex3:	cmp	al,_GRTR
	jnz	_ex4

	inc	INTP
	push	dx
	call	sum
	pop	ax
	cmp	ax,dx
	jg	true
	jmp	short false

_ex4:	cmp	al,_LSEQ
	jnz	_ex5

	inc	INTP
	push	dx
	call	sum
	pop	ax
	cmp	ax,dx
	jle	true
	jmp	short false

_ex5:	cmp	al,_GTEQ
	jnz	exx

	inc	INTP
	push	dx
	call	sum
	pop	ax
	cmp	ax,dx
	jge	true
	jmp	short false

exx:	ret
	

;;=============================================================================
;;	EXPR -- evaluate an expression
;;	IN:   -
;;	OUT:  DX=result
;;	REGS: ALL
expr:	mov	si,INTP
	mov	al,[si]
	cmp	al,_NOT
	jnz	_exp1

	inc	INTP
	call	comp
	neg	dx
	sbb	dx,dx
	not	dx
	ret

_exp1:	call	comp
	ret


;;=============================================================================
;;	STRCOPY -- copy a string
;;	IN:   SI=source DI=dest
;;	OUT:  -
;;	REGS: AX SI DI
strcopy:
	or	si,si
	jz	nomcp

	cld
mcnx:	lodsb
	stosb
	or	al,al
	jnz	mcnx

nomcp:	ret


;;=============================================================================
;;	STRLEN -- return the length of a string
;;	IN:   SI=pointer to string
;;	OUT:  AX=length
;;	REGS: AX CX SI
strlen:	xor	cx,cx
	cld

cntlen:	lodsb
	inc	cx
	or	al,al
	jnz	cntlen

	mov	ax,cx
	dec	ax
	ret


;;=============================================================================
;;	STRVAR -- return the value of a string variable
;;	IN:   -
;;	OUT:  DI=string pointer
;;	REGS: ALL
strvar:	mov	si,INTP
	mov	di,[si+1]
	add	INTP,3
	add	si,3
	cmp	byte ptr [si],_LPAR
	jnz	nosub

	push	di
	inc	INTP
	call	expr
	shl	dx,1

	mov	ax,_RPAR
	call	match

	pop	di
	add	di,dx

nosub:	cmp	di,offset ivars
	jae	badsub
	ret

badsub:	mov	ax,ESUB
	call	error


;;=============================================================================
;;	SF_CHR -- Create string from ASCII code [Basic:CHR$()]
;;	IN:   -
;;	OUT:  DI=pointer to string
;;	REGS: ALL
sf_chr:	call	expr
	mov	ax,_RPAR
	call	match
	mov	di,offset spad
	mov	[di],dl
	mov	byte ptr [di+1],0
	ret


;;=============================================================================
;;	SF_MID -- Extract a substring [Basic:MID$()]
;;	IN:   -
;;	OUT:  DI=pointer to extracted string
;;	REGS: ALL
sf_mid:	call	strexpr
	mov	ax,_COMMA
	call	match
	push	di

	call	expr
	dec	dx
	jns	nocs
	inc	dx
nocs:
	mov	tmp1,dx
	mov	tmp2,-1
	mov	si,INTP
	cmp	byte ptr [si],_COMMA
	jnz	nolen

	inc	INTP
	call	expr
	mov	tmp2,dx

nolen:	mov	ax,_RPAR
	call	match

	pop	di
	mov	si,di
	call	strlen
	cmp	ax,tmp1
	jbe	nomid

	add	di,tmp1
	mov	si,offset spad
	xchg	si,di
	call	strcopy
	mov	di,offset spad
	push	di
	mov	si,di
	call	strlen
	cmp	ax,tmp2
	jbe	nocut

	add	di,tmp2
	mov	byte ptr [di],0

nocut:	pop	di
	ret

nomid:	mov	di,offset empty
	ret


;;=============================================================================
;;	SF_STR -- Create string from a binary number [Basic:STR$()]
;;	IN:   -
;;	OUT:  DI=pointer to string
;;	REGS: ALL
sf_str:	call	expr
	mov	ax,_RPAR
	call	match
	mov	ax,dx
	call	b2a
	mov	si,di
	mov	di,offset spad
	push	di
	call	strcopy
	pop	di
	ret


;;=============================================================================
;;	STRFAC -- return a string factor
;;	IN:   -
;;	OUT:  DI=pointer to factor
;;	REGS: ALL
strfac:	mov	si,INTP
	mov	al,[si]

	cmp	al,_TXT
	jnz	_sf1

	inc	INTP
	inc	si
	cld

	push	si
txskip:	lodsb
	or	al,al
	jnz	txskip
	mov	INTP,si
	pop	di
	ret

_sf1:	cmp	al,_STR
	jnz	_sf2
	call	strvar
	mov	di,[di]
	or	di,di
	jnz	_empty
	mov	di,offset empty
_empty: ret

_sf2:	cmp	al,_CHR$
	jnz	_sf3

	inc	INTP
	call	sf_chr
	ret

_sf3:	cmp	al,_MID$
	jnz	_sf4

	inc	INTP
	call	sf_mid
	ret

_sf4:	cmp	al,_STR$
	jnz	_sf5

	inc	INTP
	call	sf_str
	ret

_sf5:	mov	ax,ESYN
	call	error


;;=============================================================================
;;	STREXPR -- evaluate a string expression
;;	IN:   -
;;	OUT:  DI=pointer to result
;;	REGS: ALL
strexpr:
	call	strfac

senx:	mov	si,INTP
	cmp	byte ptr [si],_PLUS
	jnz	noconc

	mov	si,di
	mov	di,offset spad2
	call	strcopy

	inc	INTP
	call	strfac
	mov	si,di
	call	strlen
	push	ax
	mov	si,offset spad2
	call	strlen
	mov	bx,ax
	pop	dx
	add	ax,dx
	cmp	ax,BUFL
	ja	longstr

	mov	si,di
	mov	di,offset spad2
	add	di,bx
	call	strcopy
	mov	di,offset spad2
	jmp	short senx

noconc: ret

longstr:
	mov	ax,ESBO
	call	error


;;=============================================================================
;;	LIST -- de-tokenize and display a line
;;	IN:   DI=pointer to token stream
;;	OUT:  -
;;	REGS: ALL
enddt:	call	putnl
	ret

list:	cld
	inc	di
	mov	tmp1,di
	mov	spc,0

dtok:	mov	di,tmp1
	mov	al,[di]
	inc	tmp1
	inc	di
	or	al,al
	jz	enddt

	cmp	al,_INT
	jnz	_ls1

	mov	ax,[di]
	add	tmp1,2
	call	putd

trspc:	mov	spc,0
	mov	di,tmp1
	mov	al,[di]
	xor	ah,ah
	cmp	ax,_TXT
	jae	lssp
	jmp	short dtok

lssp:	mov	ax,' '
	call	putc
	jmp	short dtok

_ls1:	cmp	al,_VAR
	jnz	_ls2

	mov	ax,[di]
	sub	ax,offset ivars
	xor	dx,dx
	mov	cx,20
	div	cx

	push	dx
	add	ax,'A'
	call	putc
	pop	ax

	or	ax,ax
	jz	_ls0
	shr	ax,1
	add	ax,'0'
	call	putc

_ls0:	add	tmp1,2
	mov	spc,0
	jmp	short dtok

_ls2:	cmp	al,_STR
	jnz	_ls3

	mov	ax,[di]
	sub	ax,offset svars
	shr	ax,1
	cmp	ax,26
	jae	dstr

	add	ax,'A'
	jmp	short strdn

dstr:	sub	ax,26-'0'

strdn:	call	putc
	mov	ax,'$'
	call	putc
	add	tmp1,2
	mov	spc,0
	jmp	dtok

_ls3:	cmp	al,_TXT
	jnz	_ls4

	mov	si,di
	push	si
	mov	ax,"'"
	call	putc
	pop	si

prtx:	lodsb
	inc	tmp1
	or	al,al
	jz	entx

	push	si
	call	putc
	pop	si
	jmp	short prtx

entx:	mov	ax,"'"
	call	putc
	mov	spc,0
	jmp	trspc

prspc:	push	ax
	mov	ax,' '
	call	putc
	pop	ax
	ret

_ls4:	mov	si,offset tokens
	xor	bx,bx

gettk:	inc	bx
	mov	ah,[si]
	and	ah,LENMASK
	jz	lfail

	cmp	al,bl
	jnz	nxtk

	push	si
	mov	cl,[si]
	and	cl,080h
	jz	_ls5
	cmp	spc,0
	jnz	_ls5
	call	prspc

_ls5:	mov	spc,0
	mov	cl,[si]
	and	cx,LENMASK
	dec	cx
	inc	si

prtk:	lodsb
	push	si
	push	cx
	call	putc
	pop	cx
	pop	si
	loop	prtk

	pop	si
	mov	cl,[si]
	and	cl,040h
	jz	_ls6
	mov	di,tmp1
	mov	al,[di]
	or	al,al
	jz	_ls6
	call	prspc
	mov	spc,1
_ls6:	jmp	dtok

nxtk:	mov	cl,[si]
	and	cx,LENMASK
	add	si,cx
	jmp	short gettk

lfail:	mov	ax,EXXX
	call	error


;;=============================================================================
;;	ALLOCSTR -- allocate a string buffer
;;	IN:   DI=string var
;;	OUT:  -
;;	REGS: ALL
allocstr:
	cmp	word ptr [di],0
	jz	alloc
	ret

alloc:	mov	ax,SBUFS
	sub	ax,BUFL+1
	cmp	ax,PTOP
	jb	nosmem

	mov	SBUFS,ax
	mov	[di],ax
	ret

nosmem:	mov	ax,EMEM
	call	error


;;=============================================================================
;;	TRACE -- print trace information
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
trace:	cmp	TRACING,0
	jz	notrace
	push	si
	mov	ax,'['
	call	putc
	mov	di,LINEP
	mov	ax,[di+2]
	call	putd
	mov	al,']'
	call	putc
	pop	si
notrace:
	ret


;;=============================================================================
;;	IPUSH -- Push nesting level information
;;	IN:   AX=ID, BX=Limit, CX=Step, DX=Var ptr, SI=Intp, DI=Line ptr
;;	OUT:  -
;;	REGS: 
ipush:	push	di
	mov	di,ISP
	cmp	di,STKL-S_LEN*2
	jae	stkovf

	add	di,offset istack
	mov	[di+S_ID],ax
	pop	ax
	mov	[di+S_LP],ax
	mov	[di+S_IP],si
	mov	[di+S_LIM],bx
	mov	[di+S_STP],cx
	mov	[di+S_VP],dx

	add	ISP,S_LEN*2
	ret

stkovf:	mov	ax,ESTK
	call	error


;;=============================================================================
;;	IPICK -- Retrieve nesting level information
;;	IN:   -
;;	OUT:  AX=ID, BX=Limit, CX=Step, DX=Var ptr, SI=Intp, DI=Line ptr
;;	REGS: ALL
ipick:	mov	di,ISP
	sub	di,S_LEN*2
	jb	stkovf

	add	di,offset istack
	mov	ax,[di+S_ID]
	mov	bx,[di+S_LIM]
	mov	cx,[di+S_STP]
	mov	dx,[di+S_VP]
	mov	si,[di+S_IP]
	mov	di,[di+S_LP]
	ret


;;=============================================================================
;;	IPOP -- remove nesting level information, uses IPUSH
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
ipop:	sub	ISP,S_LEN*2
	jb	stkovf
	ret


;;=============================================================================
;;	C_IF -- Conditional execution (Basic:IF)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_if:	inc	INTP
	pop	ax

do_and:	call	expr
	or	dx,dx
	jnz	iftrue

	cmp	LINEP,0
	jz	dook

	mov	si,LINEP
	mov	al,[si]
	xor	ah,ah
	add	si,ax
	mov	LINEP,si
	add	si,4
	mov	INTP,si
	jmp	next

iftrue:	mov	si,INTP
	cmp	byte ptr [si],_COMMA
	jnz	isok

	inc	INTP
	jmp	short do_and

isok:	jmp	next

dook:	xor	ax,ax
	call	error


;;=============================================================================
;;	C_DIM -- Dimension an array (Basic:DIM)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_dim:	inc	INTP

nxdim:	mov	si,INTP
	cmp	byte ptr [si],_VAR
	jnz	novar

	add	INTP,3
	inc	si
	mov	ax,[si]
	push	ax

	mov	ax,_LPAR
	call	match
	call	expr
	shl	dx,1
	pop	ax
	add	ax,dx

	mov	dx,PROGP
	sub	dx,PTOP
	add	dx,ax
	cmp	dx,SBUFS
	jae	nomem

	cmp	ax,PROGP
	jb	nomov

	mov	dx,ax
	call	moveprog

nomov:	mov	ax,_RPAR
	call	match

	mov	si,INTP
	cmp	byte ptr [si],_COMMA
	jnz	exdim

	inc	INTP
	jmp	short nxdim

exdim:	ret

novar:	mov	ax,ESYN
	call	error

nomem:	mov	ax,EMEM
	call	error


;;=============================================================================
;;	C_FOR -- Start a FOR-loop (Basic:FOR,TO,STEP)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_for:	inc	INTP
	call	variable
	push	di

	mov	ax,_EQU
	call	match
	call	expr
	pop	di
	push	di
	mov	[di],dx

	mov	ax,_TO
	call	match
	call	expr
	push	dx

	xor	ax,ax
	inc	ax
	push	ax
	mov	si,INTP
	cmp	byte ptr [si],_STEP
	jnz	nostp

	pop	ax
	inc	INTP
	call	expr
	push	dx
	
nostp:	mov	ax,_FOR
	pop	cx
	pop	bx
	pop	dx
	mov	si,INTP
	mov	di,LINEP
	call	ipush
	ret


;;=============================================================================
;;	C_NEXT -- terminate a FOR-loop (Basic:NEXT)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_next:	inc	INTP
	call	ipick
	cmp	ax,_FOR
	jnz	nofor

	xchg	di,dx
	add	[di],cx
	cmp	cx,0
	jl	down

	cmp	[di],bx
	jg	endfor
	jmp	short nxfor

down:	cmp	[di],bx
	jl	endfor

nxfor:	mov	LINEP,dx
	mov	INTP,si
	call	trace
	ret

endfor:	call	ipop
	ret

nofor:	mov	ax,ENST
	call	error


;;=============================================================================
;;	C_LET -- Assign a value to a variable (Basic:LET)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_let:	inc	INTP
	mov	si,INTP
	cmp	byte ptr [si],_VAR
	jnz	letstr

	call	variable
	mov	ax,_EQU
	call	match

	push	di
	call	expr
	pop	di
	mov	[di],dx
	ret

letstr:	call	strvar
	push	di
	mov	ax,_EQU
	call	match
	call	strexpr
	mov	si,di
	pop	di

	; fall thru

;;=============================================================================
;;	ASG_STR -- Assign a string to a string var
;;	IN:   SI=string, DI=dest ptr
;;	OUT:  -
;;	REGS: ALL
asg_str:
	call	allocstr
	mov	di,[di]
	call	strcopy
	ret


;;=============================================================================
;;	C_NEW -- re-initialize interpreter (&delete program) (Basic:NEW)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_new:	mov	PROGP,offset progspc
	call	c_clear

	mov	di,PROGP
	mov	byte ptr [di],0

	mov	ax,PROGP
	mov	PTOP,ax

	mov	TRACING,0
	ret


;;=============================================================================
;;	C_RUN -- Run a program (Basic:RUN)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_run:	call	c_clear
	mov	ax,PROGP
	mov	LINEP,ax
	ret


;;=============================================================================
;;	C_CALL -- Call a machine language routine
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_call:	inc	INTP
	call	expr
	call	dx
	ret


;;=============================================================================
;;	C_GOTO -- transfer control (Basic:GOTO)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_goto:	inc	INTP
	pop	ax

	call	expr
	call	findln
	jc	badln

	mov	LINEP,di
	mov	ADVANCE,0
	ret

badln:	mov	ax,EILN
	call	error


;;=============================================================================
;;	C_LIST -- list lines of a program (Basic:LIST)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_list:	mov	tmp1,0
	mov	tmp2,7FFFh
	inc	INTP

	mov	si,INTP
	cmp	byte ptr [si],0
	jz	norng

	call	expr
	mov	tmp1,dx
	mov	tmp2,dx

	mov	si,INTP
	cmp	byte ptr [si],_COMMA
	jnz	norng

	inc	INTP
	call	expr
	mov	tmp2,dx

norng:	mov	di,PROGP

skipl:	cmp	byte ptr [di],0
	jz	endlst

	mov	ax,[di+2]
	cmp	ax,tmp1
	jge	slst

	mov	al,[di]
	xor	ah,ah
	add	di,ax
	jmp	short skipl

slst:	cmp	byte ptr [di],0
	jz	endlst

	mov	ax,[di+2]
	cmp	ax,tmp2
	jg	endlst

	push	di
	call	list
	pop	di

	mov	al,[di]
	xor	ah,ah
	add	di,ax
	jmp	short slst

endlst:	ret


;;=============================================================================
;;	C_LOAD -- load a program from a device (Basic:LOAD)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_load:	cmp	IOD,-1
	jnz	inload

	inc	INTP

	mov	ax,_NOT
	call	match

	mov	ax,IDEV
	mov	IOD,ax

	call	expr
	mov	IDEV,dx
	ret

inload:	mov	ax,ENST
	call	error


;;=============================================================================
;;	C_POKE -- Change a memory cell (Basic:POKE)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_poke:	inc	INTP
	call	expr
	push	dx
	mov	ax,_COMMA
	call	match
	call	expr
	pop	di
	mov	[di],dl
	ret


;;=============================================================================
;;	NEXTDATA -- move DATA pointer, use by C_READ
;;	IN:   DX=requested type
;;	OUT:  DX=init data
;;	REGS: ALL
nextdata:
	mov	si,DATAP
	or	si,si
	jz	initd
	cmp	byte ptr [si],0
	jz	initd
	jmp	short domove

initd:	mov	si,DATAL
	or	si,si
	jz	doreset

	mov	al,[si]
	xor	ah,ah
	add	si,ax
	mov	DATAL,si
	jmp	short doinit

doreset:
	mov	ax,PROGP
	mov	DATAL,ax

doinit:	mov	si,DATAL

nxid:	mov	al,[si]
	or	al,al
	jz	eodata

	cmp	byte ptr [si+4],_DATA_
	jz	endid

	xor	ah,ah
	add	si,ax
	mov	DATAL,si
	jmp	short nxid

eodata:	mov	ax,EEOD
	call	error

endid:	add	si,5
	mov	DATAP,si

domove:	cmp	[si],dl
	jnz	badtype

	cmp	dl,_INT
	jnz	datastr

	mov	dx,[si+1]
	add	DATAP,3
	ret

datastr:
	inc	si
	push	si
	cld

skipds:	lodsb
	or	al,al
	jnz	skipds

	mov	DATAP,si
	pop	dx
	ret

badtype:
	mov	ax,ETYP
	call	error


;;=============================================================================
;;	C_READ -- initialize data (Basic:READ)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_read:	inc	INTP
rdnxt:	mov	si,INTP
	mov	al,[si]
	cmp	al,_VAR
	jnz	_rdvar

	mov	dx,_INT
	call	nextdata
	push	dx
	call	variable
	pop	ax
	mov	[di],ax
	jmp	short nxrd

_rdvar:	cmp	al,_STR
	jnz	_rdstr

	mov	dx,_TXT
	call	nextdata
	push	dx
	call	strvar
	pop	si
	call	asg_str

nxrd:	mov	si,INTP
	cmp	byte ptr [si],_COMMA
	jnz	rdex
	inc	INTP
	jmp	short rdnxt

rdex:	ret

_rdstr:	mov	ax,ESYN
	call	error


;;=============================================================================
;;	C_SAVE -- save a program to a device (Basic:SAVE)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_save:	inc	INTP
	mov	ax,_NOT
	call	match

	push	ODEV
	call	expr
	mov	ODEV,dx

	mov	di,PROGP

savnx:	cmp	byte ptr [di],0
	jz	endsav

	push	di
	call	list
	pop	di

	mov	al,[di]
	xor	ah,ah
	add	di,ax
	jmp	short savnx

endsav:	pop	ODEV
	ret


;;=============================================================================
;;	C_TRON, C_TROFF -- enable/disable tracing (Basic:TRON,TROFF)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_tron:	inc	INTP
	mov	TRACING,-1
	ret

c_troff:
	inc	INTP
	mov	TRACING,0
	ret


;;=============================================================================
;;	C_CLEAR -- clear variables and reset pointers (Basic:CLEAR)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_clear:
	call	c_restor

	mov	cx,NSTR+NVAR
	xor	ax,ax
	cld
	mov	di,offset svars
	rep	stosw

	mov	ax,WSPC
	sub	ax,RSTK
	mov	MEMTOP,ax
	mov	SBUFS,ax
	mov	si,ax
	mov	byte ptr [si],0

	mov	ISP,0

	mov	dx,offset progspc
	call	moveprog
	ret


;;=============================================================================
;;	C_GOSUB -- Branch to a subroutine (Basic:GOSUB)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_gosub:
	inc	INTP
	pop	ax

	call	expr
	call	findln
	jc	badsbr
	push	di

	mov	di,LINEP
	mov	si,INTP
	mov	ax,_GOSUB
	call	ipush

	pop	di
	mov	LINEP,di
	mov	ADVANCE,0
	ret

badsbr:	mov	ax,EILN
	call	error


;;=============================================================================
;;	C_INPUT -- read user input (Basic:INPUT)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
c_input:
	inc	INTP
	mov	si,INTP

	mov	al,[si]
	cmp	al,_NOT
	jnz	_chin

	inc	INTP
	call	expr
	mov	IDEV,dx
	ret

_chin:	mov	si,INTP
	mov	al,[si]
	or	al,al
	jz	endinp

	cmp	al,_VAR
	jnz	_inp1

	call	variable
	push	di
	mov	dx,offset spad
	call	readline
	mov	si,offset spad
	call	a2b
	pop	di
	mov	[di],dx
	jmp	short morein

_inp1:	cmp	al,_STR
	jnz	_inp2

	call	strvar
	push	di
	mov	dx,offset spad
	call	readline
	mov	si,offset spad
	call	upcase
	pop	di
	call	asg_str
	jmp	short morein

_inp2:	mov	ax,ESYN
	call	error

morein:	mov	si,INTP
	cmp	byte ptr [si],_COMMA
	jnz	endinp

	inc	INTP
	jmp	short _chin

endinp:
	ret


;;=============================================================================
;;	C_PRINT -- print expressions (Basic:PRINT)
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
prdone:	cmp	tmp1,0
	jz	endprn

	call	putnl

endprn:	ret

c_print:
	inc	INTP
	mov	si,INTP
	mov	al,[si]

	cmp	al,_NOT
	jnz	_chdev

	inc	INTP
	call	expr
	mov	ODEV,dx
	ret

_chdev:	mov	tmp1,-1

prnext:	mov	si,INTP
	mov	al,[si]
	or	al,al
	jz	prdone
	cmp	al,_COLON
	jz	prdone

	cmp	al,_MINUS
	jz	numexp
	cmp	al,_NOT
	jz	numexp
	cmp	al,_LPAR
	jz	numexp
	cmp	al,_ASC
	jz	numexp
	cmp	al,_LEN
	jz	numexp
	cmp	al,_VAL
	jz	numexp
	cmp	al,_CMPS
	jz	numexp
	cmp	al,_FRE
	jz	numexp
	cmp	al,_PEEK
	jz	numexp
	cmp	al,_IOCTL
	jz	numexp
	cmp	al,_VAR
	jz	numexp
	cmp	al,_INT
	jz	numexp
	jmp	short _pr1

numexp:	call	expr
	mov	ax,dx
	call	putd
	jmp	short prsep

_pr1:	cmp	al,_CHR$
	jz	strexp
	cmp	al,_MID$
	jz	strexp
	cmp	al,_STR$
	jz	strexp
	cmp	al,_TXT
	jz	strexp
	cmp	al,_STR
	jz	strexp
	mov	ax,ESYN
	call	error

strexp:	call	strexpr
	call	puts

prsep:	mov	si,INTP
	mov	al,[si]
	cmp	al,_COMMA
	jnz	nocomma

	inc	INTP
	mov	tmp1,0
	mov	ax,9
	call	putc
	jmp	prnext

nocomma:
	cmp	al,_SEMI
	jnz	nosemi
	inc	INTP
	mov	tmp1,0
	jmp	prnext

nosemi: mov	tmp1,-1
	jmp	prdone


;;=============================================================================
;;	C_RESTOR -- reset the DATA pointer (Basic:RESTOR)
;;	IN:   SI=line
;;	OUT:  -
;;	REGS: ALL
c_restor:
	inc	INTP
	xor	ax,ax
	mov	DATAP,ax
	mov	DATAL,ax
	ret


;;=============================================================================
;;	C_RETURN -- Return from a subroutine (Basic:RETURN)
;;	IN:   SI=line
;;	OUT:  -
;;	REGS: ALL
c_return:
	inc	INTP
	call	ipick
	cmp	ax,_GOSUB
	jnz	badnst

	mov	LINEP,di
	mov	INTP,si
	call	ipop
	call	trace
	ret

badnst:	mov	ax,ENST
	call	error


;;=============================================================================
;;	TERMINATE -- entry points for STOP, END, REM, DATA
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
terminate:
c_stop:	mov	ax,ESTP
	call	error

c_end:	xor	ax,ax
	cmp	ISP,0
	jz	stkok
	mov	ax,ESTK
stkok:	call	error

c_data:
c_rem:	pop	ax
	ret


;;=============================================================================
;;	EXECUTE -- execute a line
;;	IN:   SI=line
;;	OUT:  -
;;	REGS: ALL
execute:
	mov	INTP,si
	mov	ADVANCE,-1

	mov	ax,0B00h	; check kbd status
	int	DOS

next:	mov	si,INTP
	mov	di,offset exectbl

cktok:	mov	ah,[di]
	or	ah,ah
	jz	badtok

	mov	al,[si]
	cmp	al,ah
	jz	doexec

	add	di,3
	jmp	short cktok

badtok:	mov	ax,ESYN
	call	error

doexec:	mov	ax,[di+1]
	call	ax

	mov	si,INTP
	mov	al,[si]
	or	al,al
	jz	eol

	cmp	al,_COLON
	jnz	badtok

	inc	INTP
	jmp	short next

eol:	ret


;;=============================================================================
;;	RUN -- Run an immediate command or a program
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
run:	mov	ISP,0

	mov	si,offset scratch
	call	execute

	mov	si,LINEP
	or	si,si
	jz	endrun

nxrun:	mov	al,[si]
	or	al,al
	jz	endrun

	call	trace

	add	si,4
	call	execute

	mov	si,LINEP
	or	si,si
	jz	endrun

	cmp	ADVANCE,0
	jz	nxrun

	mov	al,[si]
	xor	ah,ah
	add	si,ax
	mov	LINEP,si
	jmp	short nxrun

endrun:	cmp	ISP,0
	jnz	stkerr
	ret

stkerr:	mov	ax,ENST
	call	error


;;=============================================================================
;;	PROCESS -- Process a line
;;	IN:   SI=line
;;	OUT:  -
;;	REGS: ALL
process:
	mov	LINEP,0
	call	tokenize

	cmp	scratch,_INT
	jnz	immed

	jmp	store

immed:	cmp	scratch,0
	jnz	run

	ret


;;=============================================================================
;;	INIT -- Initialize the interpreter
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
init:	mov	IDEV,SYSIN
	mov	ODEV,SYSOUT
	mov	IOD,-1
	call	c_new

	mov	ax,2523h	; set INT 23 vec
	mov	dx,offset break
	int	DOS
	ret

break:	mov	ax,EBRK
	call	error


;;=============================================================================
;;	INIT -- Initialize external device links
;;	IN:   -
;;	OUT:  -
;;	REGS: ALL
initdevs:
	mov	si,CMDLINE
	cld
skipb:	lodsb
	cmp	al,' '
	jz	skipb

	dec	si
	mov	dx,si

nscan:	lodsb
	or	al,al
	jz	dinit
	cmp	al,13
	jz	dinit
	cmp	al,' '
	jz	dinit
	jmp	short nscan

dinit:	inc	dx
	cmp	si,dx
	jz	enddi
	dec	dx

	push	ax
	push	dx
	push	si

	mov	byte ptr [si-1],0
	mov	ax,3D02h	; open read/write
	int	DOS

	pop	si
	pop	di
	push	di
	push	si

	push	di
	jc	nofile

	push	ax
	mov	ax,'#'
	call	putc
	pop	ax
	call	putd
	mov	di,offset equal
	call	puts
	pop	di
	call	puts
	jmp	short nxopn

nofile:	mov	di,offset minus
	call	puts
	pop	di
	call	puts

nxopn:	call	putnl
	pop	si
	pop	dx
	pop	ax

	cmp	al,13
	jz	enddi
	or	al,al
	jnz	skipb

enddi:	ret


;;=============================================================================
;;	START -- main program
;;	IN:   -
;;	OUT:  0
;;	REGS: ALL
start:	call	init

	mov	di,offset greetng
	call	puts

	call	initdevs

restart:
	mov	sp,WSPC

	mov	dx,offset line
	call	readline
	cmp	ax,-1
	jz	endrd

	mov	si,offset line
	call	process

redo:	cmp	IDEV,SYSIN
	jnz	restart

	mov	ax,EOK
	call	error

endrd:	cmp	IOD,-1
	jz	redo

	mov	ax,IOD
	mov	IDEV,ax
	mov	IOD,-1
	jmp	short redo

c_system:
	mov	ax,4C00h	; exit 0
	int	DOS


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;	S T A T I C   D A T A
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

	.data

exectbl	db	_IF
	dw	c_if
	db	_DIM
	dw	c_dim
	db	_END
	dw	c_end
	db	_FOR
	dw	c_for
	db	_LET
	dw	c_let
	db	_NEW
	dw	c_new
	db	_REM
	dw	c_rem
	db	_RUN
	dw	c_run
	db	_CALL
	dw	c_call
	db	_DATA_
	dw	c_data
	db	_GOTO
	dw	c_goto
	db	_LIST
	dw	c_list
	db	_LOAD
	dw	c_load
	db	_NEXT
	dw	c_next
	db	_POKE
	dw	c_poke
	db	_READ
	dw	c_read
	db	_SAVE
	dw	c_save
	db	_STOP
	dw	c_stop
	db	_TRON
	dw	c_tron
	db	_CLEAR
	dw	c_clear
	db	_GOSUB
	dw	c_gosub
	db	_INPUT
	dw	c_input
	db	_PRINT
	dw	c_print
	db	_RSTOR
	dw	c_restor
	db	_RETRN
	dw	c_return
	db	_SYSTM
	dw	c_system
	db	_TROFF
	dw	c_troff
	db	0

greetng	db	"NMH BASIC 2.1", 13, 10, 0

tokens	db	 66, '#'
	db	  2, "'"
	db	  2, '('
	db	  2, ')'
	db	  2, '*'
	db	  2, '+'
	db	 66, ','
	db	  2, '-'
	db	  2, '/'
	db	  2, '\'
	db	194, ':'
	db	 66, ';'
	db	194, '<'
	db	194, '='
	db	194, '>'
	db	195, '<='
	db	195, '<>'
	db	195, '>='
	db	195, 'IF'
	db	195, 'TO'
	db	196, 'DIM'
	db	196, 'END'
	db	196, 'FOR'
	db	196, 'LET'
	db	196, 'NEW'
	db	196, 'REM'
	db	196, 'RUN'
	db	  5, 'ASC('
	db	197, 'DATA'
	db	197, 'GOTO'
	db	  5, 'LEN('
	db	197, 'CALL'
	db	  5, 'FRE('
	db	197, 'LIST'
	db	197, 'LOAD'
	db	197, 'NEXT'
	db	197, 'POKE'
	db	197, 'READ'
	db	197, 'SAVE'
	db	197, 'STEP'
	db	197, 'STOP'
	db	197, 'TRON'
	db	  5, 'VAL('
	db	  6, 'CHR$('
	db	  6, 'CMPS('
	db	198, 'CLEAR'
	db	198, 'GOSUB'
	db	198, 'INPUT'
	db	  6, 'MID$('
	db	  6, 'PEEK('
	db	198, 'PRINT'
	db	  6, 'STR$('
	db	198, 'TROFF'
	db	  7, 'IOCTL('
	db	199, 'RESTOR'
	db	199, 'RETURN'
	db	199, 'SYSTEM'
	db	0

errhd	db	'**', 0
errmid	db	' : ', 0
equal	db	' = ', 0
minus	db	'! ', 0
crlf	db	13, 10
empty	db	0
msgs	db	' OK',0, 'LLO',0, 'OVF',0, 'SYN',0, 'ILN',0, 'DIV',0
	db	'SBO',0, 'SUB',0, 'MEM',0, 'NIM',0, 'STK',0, 'NST',0
	db	'TYP',0, 'EOD',0, 'ARG',0, 'STP',0, 'BRK',0, 'XXX',0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;	D Y N A M I C   D A T A
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

tmp1	dw	?
tmp2	dw	?
spc	db	?		; list space indicator
conv	db	7 dup (?)	; num conv, also token buf
econv	db	?		; end of conv
istack	dw	STKL dup (?)	; stack
line	db	BUFL+2 dup (?)	; line buf
scratch	db	BUFL+2 dup (?)	; scratchpad
spad	db	BUFL+2 dup (?)	; aux pad
spad2	db	BUFL+2 dup (?)	; aux pad 2
svars	dw	NSTR dup (?)	; string vars
ivars	dw	NVAR dup (?)	; int vars
progspc	db	?		; program space


	end	prog

